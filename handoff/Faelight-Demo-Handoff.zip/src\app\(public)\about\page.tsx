import type { Metadata } from "next";
import Link from "next/link";
import { CONTACT, FOUNDER, TEAM } from "@/lib/content";
import { Eyebrow, Fireflies, Glow, Star, StarDivider } from "@/components/Motifs";
import { CtaBand } from "@/components/Sections";

export const metadata: Metadata = {
  title: "About — Maia & the Faelight Team",
  description:
    "Meet Maria “Maia” Castañeda, founder of Faelight, and the team behind the mentoring, systems and experiences work.",
};

export default function AboutPage() {
  return (
    <>
      <section className="starfield relative overflow-hidden bg-enchanted text-parchment">
        <Fireflies count={14} />
        <Glow className="-left-16 top-4" size={480} />
        <Glow className="right-0 top-1/3" color="rgba(90,68,128,0.55)" size={440} />
        <div className="container-fae relative z-10 py-14 sm:py-16">
          <div className="grid items-center gap-8 lg:grid-cols-[1.2fr_0.8fr] lg:gap-12">
            <div>
              <Eyebrow light>About Faelight</Eyebrow>
              <h1 className="mt-4 max-w-2xl font-serif text-3xl leading-tight sm:text-4xl">
                Built from lived experience, not generic templates.
              </h1>
              <p className="mt-5 max-w-xl text-parchment/75">
                Faelight is a small team with a big belief: people come first,
                systems come second, and a little magic belongs in the middle of
                serious work.
              </p>
            </div>
            <div className="relative hidden justify-center lg:flex">
              <Glow className="left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" color="rgba(230,183,82,0.25)" size={300} />
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/brand/logo-full.png"
                alt="Faelight Business Consultancy logo"
                className="relative max-h-72 w-auto animate-floatSlow drop-shadow-[0_8px_30px_rgba(230,183,82,0.25)]"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Founder ---------------------------------------------------- */}
      <section className="section">
        <div className="container-fae grid gap-10 lg:grid-cols-5 lg:items-center">
          <div className="lg:col-span-2">
            <div className="relative mx-auto max-w-sm">
              <Glow className="-right-4 -top-4" size={280} />
              <div className="card relative bg-enchanted text-center text-parchment">
                <Fireflies count={7} />
                <div className="relative z-10">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="/brand/maia-portrait.jpg"
                    alt="Maria “Maia” Castañeda"
                    className="mx-auto h-32 w-32 rounded-full object-cover shadow-glow ring-2 ring-firefly/50"
                  />
                  <p className="mt-5 font-serif text-2xl">{FOUNDER.name}</p>
                  <p className="mt-1 text-sm text-firefly-bright/80">{FOUNDER.title}</p>
                  <div className="mt-4 flex flex-wrap justify-center gap-2">
                    {FOUNDER.personal.map((p) => (
                      <span key={p} className="rounded-full border border-firefly/40 px-3 py-1 text-xs text-parchment/80">
                        {p}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <Eyebrow>The founder</Eyebrow>
            <h2 className="mt-3 font-serif text-3xl text-forest-deep">{FOUNDER.role}</h2>
            <p className="mt-4 text-ink-soft">{FOUNDER.bio}</p>
            <div className="mt-8 grid gap-4 sm:grid-cols-3">
              {FOUNDER.stats.map((s) => (
                <div key={s.label} className="card text-center">
                  <p className="font-serif text-3xl text-forest">{s.value}</p>
                  <p className="mt-1 text-xs uppercase tracking-wide text-ink-faint">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <StarDivider />

      {/* Team ------------------------------------------------------- */}
      <section id="team" className="section scroll-mt-24">
        <div className="container-fae">
          <div className="text-center">
            <Eyebrow>The team</Eyebrow>
            <h2 className="mt-3 font-serif text-2xl text-forest-deep sm:text-3xl">
              The people behind the magic
            </h2>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {TEAM.map((m) => (
              <div key={m.id} className="card-hover flex items-start gap-4">
                {m.photo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={m.photo}
                    alt={m.name}
                    className="h-16 w-16 shrink-0 rounded-2xl object-cover shadow-card ring-1 ring-firefly/30"
                  />
                ) : (
                  <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-twilight to-forest text-xl text-firefly-bright">
                    <Star />
                  </div>
                )}
                <div>
                  <p className="font-serif text-lg text-forest-deep">{m.name}</p>
                  <p className="text-xs font-semibold uppercase tracking-wide text-firefly-deep">{m.role}</p>
                  <p className="mt-2 text-sm text-ink-soft">{m.blurb}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact quick strip --------------------------------------- */}
      <section className="pb-8">
        <div className="container-fae">
          <div className="card flex flex-col items-center justify-between gap-4 text-center sm:flex-row sm:text-left">
            <div>
              <p className="font-serif text-xl text-forest-deep">Want to work with us?</p>
              <p className="text-sm text-ink-soft">
                {CONTACT.name} · {CONTACT.email} · {CONTACT.phone}
              </p>
            </div>
            <div className="flex gap-3">
              <Link href="/book" className="btn-primary">Book a call</Link>
              <Link href="/contact" className="btn-ghost">Contact</Link>
            </div>
          </div>
        </div>
      </section>

      <CtaBand />
    </>
  );
}
