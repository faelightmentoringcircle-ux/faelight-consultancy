"use client";

import { useEffect, useMemo, useState } from "react";
import {
  getReviews, updateReview, removeReview, onStoreChange, Review, ReviewStatus,
} from "@/lib/store";
import { relativeDay } from "@/lib/format";
import { AdminHeader, Panel, StatTile, CategoryTag } from "@/components/admin/ui";

const STATUS_STYLES: Record<ReviewStatus, string> = {
  pending: "bg-amber-100 text-amber-800",
  approved: "bg-emerald-100 text-emerald-700",
  rejected: "bg-rose-100 text-rose-700",
};

export default function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [tab, setTab] = useState<ReviewStatus | "all">("pending");

  useEffect(() => {
    const sync = () => setReviews(getReviews());
    sync();
    return onStoreChange(sync);
  }, []);

  const counts = {
    pending: reviews.filter((r) => r.status === "pending").length,
    approved: reviews.filter((r) => r.status === "approved").length,
    rejected: reviews.filter((r) => r.status === "rejected").length,
  };
  const shown = useMemo(
    () => (tab === "all" ? reviews : reviews.filter((r) => r.status === tab)),
    [reviews, tab]
  );

  return (
    <>
      <AdminHeader
        title="Reviews"
        subtitle="Approve client reviews before they appear on the public site."
      />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatTile label="Awaiting approval" value={counts.pending} accent="firefly" />
        <StatTile label="Published" value={counts.approved} hint="live on the site" accent="forest" />
        <StatTile label="Rejected" value={counts.rejected} accent="twilight" />
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {(["pending", "approved", "rejected", "all"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`rounded-full border px-4 py-1.5 text-xs font-semibold capitalize transition ${
              tab === t ? "border-forest bg-forest text-parchment" : "border-firefly/25 bg-parchment-card text-ink-soft hover:border-firefly"
            }`}
          >
            {t}{t !== "all" ? ` · ${counts[t]}` : ""}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {shown.length === 0 && (
          <Panel><p className="py-6 text-center text-ink-faint">No {tab === "all" ? "" : tab} reviews.</p></Panel>
        )}
        {shown.map((r) => (
          <Panel key={r.id}>
            <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-medium text-forest-deep">{r.author}</p>
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ${STATUS_STYLES[r.status]}`}>{r.status}</span>
                  {r.rating && <span className="text-sm text-firefly">{"★".repeat(r.rating)}</span>}
                  <CategoryTag slug={r.categorySlug} />
                  <span className="text-xs text-ink-faint">{relativeDay(r.createdAt)}</span>
                </div>
                <p className="text-xs text-ink-faint">{r.roleCompany}</p>
                <blockquote className="mt-2 border-l-2 border-firefly/40 pl-3 font-serif text-forest-deep">
                  “{r.quote}”
                </blockquote>
              </div>

              <div className="flex shrink-0 flex-wrap items-center gap-2 sm:flex-col sm:items-stretch">
                {r.status !== "approved" && (
                  <button onClick={() => updateReview(r.id, { status: "approved" })} className="rounded-lg border border-emerald-400 px-3 py-1.5 text-xs font-semibold text-emerald-700 hover:bg-emerald-50">
                    ✓ Approve &amp; publish
                  </button>
                )}
                {r.status === "approved" && (
                  <button onClick={() => updateReview(r.id, { status: "pending" })} className="rounded-lg border border-firefly/30 px-3 py-1.5 text-xs font-semibold text-ink-soft hover:border-firefly">
                    Unpublish
                  </button>
                )}
                {r.status !== "rejected" && (
                  <button onClick={() => updateReview(r.id, { status: "rejected" })} className="rounded-lg border border-rose-300 px-3 py-1.5 text-xs font-semibold text-rose-700 hover:bg-rose-50">
                    Reject
                  </button>
                )}
                <button onClick={() => { if (confirm("Delete this review permanently?")) removeReview(r.id); }} className="text-xs font-semibold text-ink-faint hover:text-rose-600">
                  Delete
                </button>
              </div>
            </div>
          </Panel>
        ))}
      </div>
    </>
  );
}
