"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { Wordmark } from "./Wordmark";

const NAV = [
  { href: "/about", label: "About" },
  { href: "/mentoring", label: "Mentoring" },
  { href: "/systems", label: "Systems" },
  { href: "/experiences", label: "Experiences" },
  { href: "/pricing", label: "Pricing" },
  { href: "/brochures", label: "Brochures" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "border-b border-firefly/15 bg-parchment/90 backdrop-blur-md"
          : "border-b border-transparent bg-parchment/70 backdrop-blur"
      }`}
    >
      <div className="container-fae flex h-16 items-center justify-between">
        <Wordmark />

        <nav className="hidden items-center gap-7 lg:flex">
          {NAV.map((item) => {
            const active = pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`link-underline text-sm font-medium transition-colors ${
                  active ? "text-forest" : "text-ink-soft hover:text-forest"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
          <Link href="/contact" className="text-sm font-medium text-ink-soft hover:text-forest link-underline">
            Contact
          </Link>
          <Link href="/book" className="btn-primary !px-5 !py-2.5">
            Book a Discovery Call
          </Link>
        </nav>

        <button
          onClick={() => setOpen((o) => !o)}
          className="grid h-10 w-10 place-items-center rounded-full border border-firefly/25 text-forest lg:hidden"
          aria-label="Toggle menu"
          aria-expanded={open}
        >
          <span className="text-lg">{open ? "✕" : "☰"}</span>
        </button>
      </div>

      {open && (
        <div className="border-t border-firefly/15 bg-parchment lg:hidden">
          <nav className="container-fae flex flex-col py-4">
            {[...NAV, { href: "/contact", label: "Contact" }].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="border-b border-firefly/10 py-3 text-sm font-medium text-ink-soft"
              >
                {item.label}
              </Link>
            ))}
            <Link href="/book" className="btn-primary mt-4">
              Book a Discovery Call
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
