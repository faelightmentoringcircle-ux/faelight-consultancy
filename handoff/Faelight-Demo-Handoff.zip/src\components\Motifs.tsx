// Fantasy visual motifs — stars, glows, dividers. Purely decorative,
// so all are aria-hidden. Motion respects prefers-reduced-motion via CSS.

export function Star({ className = "" }: { className?: string }) {
  return <span aria-hidden className={className}>✦</span>;
}

export function StarLight({ className = "" }: { className?: string }) {
  return <span aria-hidden className={className}>✧</span>;
}

// A soft firefly glow blob to place behind content.
export function Glow({
  className = "",
  color = "rgba(230,183,82,0.35)",
  size = 420,
}: {
  className?: string;
  color?: string;
  size?: number;
}) {
  return (
    <div
      aria-hidden
      className={`pointer-events-none absolute rounded-full blur-3xl ${className}`}
      style={{
        width: size,
        height: size,
        background: `radial-gradient(closest-side, ${color}, transparent)`,
      }}
    />
  );
}

// A few gently twinkling fireflies scattered in a container.
export function Fireflies({ count = 8 }: { count?: number }) {
  const dots = Array.from({ length: count }, (_, i) => {
    const top = (i * 37) % 90 + 3;
    const left = (i * 53) % 92 + 3;
    const delay = (i % 5) * 0.7;
    const size = 3 + (i % 3);
    return (
      <span
        key={i}
        className="absolute rounded-full bg-firefly-bright animate-twinkle"
        style={{
          top: `${top}%`,
          left: `${left}%`,
          width: size,
          height: size,
          animationDelay: `${delay}s`,
          boxShadow: "0 0 8px 2px rgba(244,212,136,0.6)",
        }}
      />
    );
  });
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {dots}
    </div>
  );
}

// Elegant star divider between sections.
export function StarDivider({ light = false }: { light?: boolean }) {
  const line = light ? "bg-parchment/25" : "bg-firefly/30";
  const star = light ? "text-firefly-bright" : "text-firefly";
  return (
    <div aria-hidden className="flex items-center justify-center gap-4 py-2">
      <span className={`h-px w-16 ${line}`} />
      <span className={`text-sm ${star}`}>✦</span>
      <span className={`h-px w-16 ${line}`} />
    </div>
  );
}

// Section eyebrow: letter-spaced small-caps with a leading star.
export function Eyebrow({
  children,
  light = false,
}: {
  children: React.ReactNode;
  light?: boolean;
}) {
  return (
    <p className={light ? "eyebrow-light" : "eyebrow"}>
      <span aria-hidden>✦</span>
      {children}
    </p>
  );
}
