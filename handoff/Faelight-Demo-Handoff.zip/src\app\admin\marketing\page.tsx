"use client";

import { useEffect, useMemo, useState } from "react";
import {
  getLeads, subscribers, getCampaigns, addCampaign, updateCampaign, removeCampaign,
  getSocialAccounts, saveSocialAccount, getVideos, addVideo, removeVideo,
  getIntros, addIntro, updateIntro, removeIntro, onStoreChange,
  runDueCampaigns, getAutomations, saveAutomations,
  getBrands, addBrand, updateBrand, removeBrand, BRAND_GROUPS,
  Lead, Campaign, SocialAccount, VideoItem, IntroItem, Automations, Brand,
} from "@/lib/store";
import { CATEGORIES, CategorySlug } from "@/lib/content";
import { formatDateTime, relativeDay } from "@/lib/format";
import { useAuth } from "@/lib/auth";
import { AdminHeader, Panel, StatTile } from "@/components/admin/ui";

type Tab = "email" | "social" | "content" | "brands";

export default function MarketingPage() {
  const [tab, setTab] = useState<Tab>("email");
  return (
    <>
      <AdminHeader
        title="Marketing"
        subtitle="Email marketing, social accounts and content — managed by Kits & Josh."
      />
      <div className="mb-6 flex flex-wrap gap-2">
        {([
          ["email", "✉ Email marketing"],
          ["social", "◎ Social accounts"],
          ["content", "▶ Videos & intros"],
          ["brands", "✦ Brands & clients"],
        ] as [Tab, string][]).map(([t, label]) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
              tab === t ? "border-forest bg-forest text-parchment" : "border-firefly/25 bg-parchment-card text-ink-soft hover:border-firefly"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "email" && <EmailMarketing />}
      {tab === "social" && <SocialAccounts />}
      {tab === "content" && <VideosIntros />}
      {tab === "brands" && <BrandsManager />}
    </>
  );
}

// ======================= BRANDS & CLIENTS =======================
function BrandsManager() {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [form, setForm] = useState({ name: "", group: BRAND_GROUPS[0], logoUrl: "" });

  useEffect(() => {
    const sync = () => setBrands(getBrands());
    sync();
    return onStoreChange(sync);
  }, []);

  const input = "w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly";

  function onFile(e: React.ChangeEvent<HTMLInputElement>, cb: (dataUrl: string) => void) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500_000) { alert("Please use an image under 500KB."); return; }
    const reader = new FileReader();
    reader.onload = () => cb(String(reader.result));
    reader.readAsDataURL(file);
  }

  function add() {
    if (!form.name.trim()) return;
    addBrand({ name: form.name.trim(), group: form.group, logoUrl: form.logoUrl || undefined });
    setForm({ name: "", group: form.group, logoUrl: "" });
  }

  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-firefly/25 bg-firefly/8 p-3 text-xs text-ink-soft">
        <span className="font-semibold text-forest-deep">✦</span> Add the clients &amp; brands you support.
        Upload a logo (or paste a URL) and they appear in the <strong>“Clients and Brands We Support”</strong> section
        on the homepage. Untick “Show” to hide one without deleting it.
      </div>

      {/* Add form */}
      <Panel>
        <h2 className="font-serif text-lg text-forest-deep">Add a brand</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Brand name</label>
            <input className={input} value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="e.g. Mean Bean Coffee Co." />
          </div>
          <div>
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Group</label>
            <select className={input} value={form.group} onChange={(e) => setForm((f) => ({ ...f, group: e.target.value }))}>
              {BRAND_GROUPS.map((g) => (<option key={g} value={g}>{g}</option>))}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Logo</label>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <input className={input} value={form.logoUrl.startsWith("data:") ? "" : form.logoUrl} onChange={(e) => setForm((f) => ({ ...f, logoUrl: e.target.value }))} placeholder="Paste logo URL, or upload →" />
              <label className="shrink-0 cursor-pointer rounded-lg border border-firefly/30 px-3 py-2 text-xs font-semibold text-forest hover:border-firefly">
                Upload
                <input type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e, (d) => setForm((f) => ({ ...f, logoUrl: d })))} />
              </label>
              {form.logoUrl && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={form.logoUrl} alt="preview" className="h-9 w-14 rounded border border-firefly/20 bg-white object-contain p-0.5" />
              )}
            </div>
            <p className="mt-1 text-[11px] text-ink-faint">Optional — without a logo, the brand shows as a name. Uploads are stored locally (≤500KB).</p>
          </div>
        </div>
        <button onClick={add} disabled={!form.name.trim()} className="btn-primary mt-3 !px-4 !py-2 text-sm disabled:opacity-40">+ Add brand</button>
      </Panel>

      {/* Grouped list */}
      {BRAND_GROUPS.filter((g) => brands.some((b) => b.group === g)).map((group) => (
        <div key={group}>
          <h3 className="mb-2 font-serif text-base text-forest-deep">{group} <span className="text-xs text-ink-faint">({brands.filter((b) => b.group === group).length})</span></h3>
          <div className="grid gap-2 sm:grid-cols-2">
            {brands.filter((b) => b.group === group).map((b) => (
              <div key={b.id} className={`flex items-center gap-3 rounded-xl border border-firefly/15 bg-parchment-card p-2.5 ${b.active ? "" : "opacity-50"}`}>
                <label className="group relative grid h-10 w-14 shrink-0 cursor-pointer place-items-center overflow-hidden rounded bg-white ring-1 ring-firefly/15" title={b.logoUrl ? "Replace logo" : "Upload a logo"}>
                  {b.logoUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={b.logoUrl} alt={b.name} className="max-h-full max-w-full object-contain p-0.5" />
                  ) : (
                    <span className="text-[9px] font-semibold text-firefly-deep">＋ Logo</span>
                  )}
                  <span className="absolute inset-0 hidden place-items-center bg-forest/70 text-[8px] font-bold text-parchment group-hover:grid">
                    {b.logoUrl ? "REPLACE" : "UPLOAD"}
                  </span>
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e, (d) => updateBrand(b.id, { logoUrl: d }))} />
                </label>
                <p className="min-w-0 flex-1 truncate text-sm font-medium text-forest-deep">{b.name}</p>
                {b.logoUrl && (
                  <button onClick={() => updateBrand(b.id, { logoUrl: undefined })} title="Remove logo" className="text-xs text-ink-faint hover:text-rose-600">⌫</button>
                )}
                <label className="flex items-center gap-1 text-[11px] text-ink-soft">
                  <input type="checkbox" checked={b.active} onChange={(e) => updateBrand(b.id, { active: e.target.checked })} className="h-3.5 w-3.5 rounded border-firefly/40 text-forest focus:ring-firefly" />
                  Show
                </label>
                <button onClick={() => { if (confirm(`Remove ${b.name}?`)) removeBrand(b.id); }} className="text-xs font-semibold text-rose-600 hover:underline">✕</button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ============================ EMAIL ============================
function EmailMarketing() {
  const { user } = useAuth();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [subs, setSubs] = useState<Lead[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [autos, setAutos] = useState<Automations>({ autoWelcome: true, monthlyDigest: false });
  const [form, setForm] = useState({ subject: "", body: "", audience: "all" as "all" | CategorySlug, scheduledAt: "" });

  useEffect(() => {
    const sync = () => {
      runDueCampaigns(); // automation: send any scheduled campaigns now due
      setLeads(getLeads());
      setSubs(subscribers());
      setCampaigns(getCampaigns());
      setAutos(getAutomations());
    };
    sync();
    const unsub = onStoreChange(sync);
    const timer = setInterval(sync, 20000); // keep checking while open
    return () => { unsub(); clearInterval(timer); };
  }, []);

  const audienceCount = (aud: "all" | CategorySlug) =>
    aud === "all" ? subs.length : subs.filter((l) => l.categorySlug === aud).length;

  function create(status: "draft" | "sent" | "scheduled") {
    if (!form.subject.trim()) return;
    if (status === "scheduled" && !form.scheduledAt) return;
    const count = audienceCount(form.audience);
    addCampaign({
      subject: form.subject.trim(),
      body: form.body.trim(),
      audience: form.audience,
      author: user?.name ?? "Team",
      status,
      ...(status === "sent" ? { sentAt: new Date().toISOString(), recipientCount: count } : {}),
      ...(status === "scheduled" ? { scheduledAt: new Date(form.scheduledAt).toISOString() } : {}),
    });
    setForm({ subject: "", body: "", audience: "all", scheduledAt: "" });
  }

  function send(c: Campaign) {
    const count = audienceCount(c.audience);
    if (confirm(`Send "${c.subject}" to ${count} subscriber(s)? In production this sends via your email service (Resend/Mailchimp).`)) {
      updateCampaign(c.id, { status: "sent", sentAt: new Date().toISOString(), recipientCount: count });
    }
  }

  const sent = campaigns.filter((c) => c.status === "sent").length;
  const drafts = campaigns.filter((c) => c.status === "draft").length;
  const input = "w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly";

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <StatTile label="Mailing list" value={subs.length} hint={`of ${leads.length} leads opted in`} accent="twilight" />
        <StatTile label="Campaigns sent" value={sent} accent="forest" />
        <StatTile label="Drafts" value={drafts} accent="firefly" />
      </div>

      <div className="mb-2 rounded-xl border border-firefly/25 bg-firefly/8 p-3 text-xs text-ink-soft">
        <span className="font-semibold text-forest-deep">✦ Demo note:</span> subscribers are captured
        automatically from bookings &amp; the inquiry form (opt-in). Sending is simulated — in production
        it goes out through your email service and tracks opens/clicks.
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Composer */}
        <Panel>
          <h2 className="font-serif text-lg text-forest-deep">New campaign</h2>
          <div className="mt-3 space-y-3">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Subject</label>
              <input className={input} value={form.subject} onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))} placeholder="Your email subject line" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Audience</label>
              <select className={input} value={form.audience} onChange={(e) => setForm((f) => ({ ...f, audience: e.target.value as "all" | CategorySlug }))}>
                <option value="all">Everyone on the list ({audienceCount("all")})</option>
                {CATEGORIES.map((c) => (
                  <option key={c.slug} value={c.slug}>{c.name} interest ({audienceCount(c.slug)})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Message</label>
              <textarea rows={5} className={input} value={form.body} onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))} placeholder="Write your update…" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Schedule for later <span className="normal-case text-ink-faint">(optional)</span></label>
              <input type="datetime-local" className={input} value={form.scheduledAt} onChange={(e) => setForm((f) => ({ ...f, scheduledAt: e.target.value }))} />
            </div>
            <div className="flex flex-wrap gap-2">
              <button onClick={() => create("draft")} disabled={!form.subject.trim()} className="btn-ghost !px-4 !py-2 text-sm disabled:opacity-40">Save draft</button>
              {form.scheduledAt ? (
                <button onClick={() => create("scheduled")} disabled={!form.subject.trim()} className="btn-primary !px-4 !py-2 text-sm disabled:opacity-40">◷ Schedule send</button>
              ) : (
                <button onClick={() => create("sent")} disabled={!form.subject.trim()} className="btn-primary !px-4 !py-2 text-sm disabled:opacity-40">Send now</button>
              )}
            </div>
          </div>
        </Panel>

        {/* Subscribers */}
        <Panel>
          <h2 className="font-serif text-lg text-forest-deep">Subscribers ({subs.length})</h2>
          <p className="text-xs text-ink-faint">Everyone who opted into updates.</p>
          <div className="mt-3 max-h-72 space-y-2 overflow-auto pr-1">
            {subs.length === 0 && <p className="text-sm text-ink-faint">No subscribers yet.</p>}
            {subs.map((s) => (
              <div key={s.id} className="flex items-center justify-between rounded-lg border border-firefly/12 px-3 py-2 text-sm">
                <div className="min-w-0">
                  <p className="truncate font-medium text-forest-deep">{s.name}</p>
                  <p className="truncate text-xs text-ink-faint">{s.email}</p>
                </div>
                {s.categorySlug && <span className="shrink-0 rounded-full bg-forest/8 px-2 py-0.5 text-[10px] capitalize text-forest">{s.categorySlug}</span>}
              </div>
            ))}
          </div>
        </Panel>
      </div>

      {/* Automations */}
      <Panel>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-serif text-lg text-forest-deep">Automations</h2>
            <p className="text-xs text-ink-faint">Standing rules that run on their own — no manual send needed.</p>
          </div>
          <span className="text-xl text-firefly">⚡</span>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <AutomationToggle
            on={autos.autoWelcome}
            title="Auto-welcome new subscribers"
            desc="Every new opt-in automatically receives the welcome email."
            onToggle={() => saveAutomations({ autoWelcome: !autos.autoWelcome })}
          />
          <AutomationToggle
            on={autos.monthlyDigest}
            title="Monthly digest reminder"
            desc="Nudge the team to send the monthly roundup on the 1st."
            onToggle={() => saveAutomations({ monthlyDigest: !autos.monthlyDigest })}
          />
        </div>
        <p className="mt-3 text-xs text-ink-faint">
          Scheduled campaigns send automatically at their set time (this demo checks while the page is open;
          production uses a server cron/queue).
        </p>
      </Panel>

      {/* Campaign history */}
      <Panel>
        <h2 className="font-serif text-lg text-forest-deep">Campaigns</h2>
        <div className="mt-3 space-y-2">
          {campaigns.length === 0 && <p className="text-sm text-ink-faint">No campaigns yet.</p>}
          {campaigns.map((c) => (
            <div key={c.id} className="rounded-xl border border-firefly/15 p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-medium text-forest-deep">{c.subject}</p>
                  <p className="text-xs text-ink-faint">
                    To {c.audience === "all" ? "everyone" : `${c.audience} interest`} · by {c.author} ·{" "}
                    {c.status === "sent"
                      ? `sent ${relativeDay(c.sentAt!)} to ${c.recipientCount}`
                      : c.status === "scheduled"
                      ? `⏱ scheduled for ${formatDateTime(c.scheduledAt!)}`
                      : `draft · ${relativeDay(c.createdAt)}`}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <CampaignBadge status={c.status} />
                  {c.status !== "sent" && (
                    <button onClick={() => send(c)} className="rounded-lg border border-forest/30 px-3 py-1.5 text-xs font-semibold text-forest hover:border-firefly">Send</button>
                  )}
                  <button onClick={() => { if (confirm("Delete this campaign?")) removeCampaign(c.id); }} className="text-xs font-semibold text-rose-600 hover:underline">Delete</button>
                </div>
              </div>
              {c.body && <p className="mt-2 line-clamp-2 text-xs text-ink-soft">{c.body}</p>}
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

function CampaignBadge({ status }: { status: Campaign["status"] }) {
  const map = { draft: "bg-stone-200 text-stone-600", scheduled: "bg-amber-100 text-amber-800", sent: "bg-emerald-100 text-emerald-700" };
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ${map[status]}`}>{status}</span>;
}

function AutomationToggle({
  on, title, desc, onToggle,
}: {
  on: boolean; title: string; desc: string; onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className={`flex items-start gap-3 rounded-xl border p-3 text-left transition ${
        on ? "border-forest bg-forest/5" : "border-firefly/20 hover:border-firefly/50"
      }`}
    >
      <span className={`mt-0.5 flex h-5 w-9 shrink-0 items-center rounded-full p-0.5 transition ${on ? "bg-forest" : "bg-stone-300"}`}>
        <span className={`h-4 w-4 rounded-full bg-white transition ${on ? "translate-x-4" : ""}`} />
      </span>
      <span>
        <span className="block text-sm font-semibold text-forest-deep">{title}</span>
        <span className="mt-0.5 block text-xs text-ink-soft">{desc}</span>
      </span>
    </button>
  );
}

// ============================ SOCIAL ============================
const SOCIAL_GLYPH: Record<string, string> = {
  facebook: "f", instagram: "◉", linkedin: "in", tiktok: "♪", youtube: "▶",
};

function SocialAccounts() {
  const [accounts, setAccounts] = useState<SocialAccount[]>([]);
  useEffect(() => {
    const sync = () => setAccounts(getSocialAccounts());
    sync();
    return onStoreChange(sync);
  }, []);
  const input = "w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly";

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-firefly/25 bg-firefly/8 p-3 text-xs text-ink-soft">
        <span className="font-semibold text-forest-deep">✦</span> Link Faelight's social accounts here.
        Handles &amp; links feed the site footer and campaigns. (Marked connected = live.)
      </div>
      {accounts.map((a) => (
        <Panel key={a.platform}>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex items-center gap-3 sm:w-44 sm:shrink-0">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-twilight to-forest text-sm font-bold text-firefly-bright">
                {SOCIAL_GLYPH[a.platform] ?? "✦"}
              </span>
              <div>
                <p className="font-semibold text-forest-deep">{a.label}</p>
                <span className={`text-[11px] font-semibold ${a.connected ? "text-emerald-600" : "text-ink-faint"}`}>
                  {a.connected ? "● Connected" : "Not linked"}
                </span>
              </div>
            </div>
            <div className="grid flex-1 gap-2 sm:grid-cols-2">
              <input className={input} defaultValue={a.handle} placeholder="Handle (@name)" onBlur={(e) => saveSocialAccount(a.platform, { handle: e.target.value })} />
              <input className={input} defaultValue={a.url} placeholder="https://…" onBlur={(e) => saveSocialAccount(a.platform, { url: e.target.value, connected: !!e.target.value.trim() })} />
            </div>
            <button
              onClick={() => saveSocialAccount(a.platform, { connected: !a.connected })}
              className={`shrink-0 rounded-lg border px-3 py-2 text-xs font-semibold transition ${a.connected ? "border-firefly/30 text-ink-soft hover:border-firefly" : "border-forest/30 text-forest hover:border-firefly"}`}
            >
              {a.connected ? "Unlink" : "Mark linked"}
            </button>
          </div>
        </Panel>
      ))}
    </div>
  );
}

// ======================= VIDEOS & INTROS =======================
function VideosIntros() {
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [intros, setIntros] = useState<IntroItem[]>([]);
  const [vForm, setVForm] = useState({ title: "", url: "", description: "", kind: "intro" as VideoItem["kind"] });
  const [iForm, setIForm] = useState({ title: "", text: "" });

  useEffect(() => {
    const sync = () => { setVideos(getVideos()); setIntros(getIntros()); };
    sync();
    return onStoreChange(sync);
  }, []);
  const input = "w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly";

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Videos */}
      <div className="space-y-4">
        <Panel>
          <h2 className="font-serif text-lg text-forest-deep">Add a video</h2>
          <p className="text-xs text-ink-faint">Brand intros, promos and short clips (paste a YouTube / Vimeo link).</p>
          <div className="mt-3 space-y-2">
            <input className={input} placeholder="Title" value={vForm.title} onChange={(e) => setVForm((f) => ({ ...f, title: e.target.value }))} />
            <input className={input} placeholder="Video URL" value={vForm.url} onChange={(e) => setVForm((f) => ({ ...f, url: e.target.value }))} />
            <div className="flex gap-2">
              <select className={input} value={vForm.kind} onChange={(e) => setVForm((f) => ({ ...f, kind: e.target.value as VideoItem["kind"] }))}>
                <option value="intro">Intro</option>
                <option value="promo">Promo</option>
                <option value="testimonial">Testimonial</option>
                <option value="other">Other</option>
              </select>
            </div>
            <textarea className={input} rows={2} placeholder="Short description" value={vForm.description} onChange={(e) => setVForm((f) => ({ ...f, description: e.target.value }))} />
            <button
              onClick={() => { if (vForm.title.trim()) { addVideo(vForm); setVForm({ title: "", url: "", description: "", kind: "intro" }); } }}
              disabled={!vForm.title.trim()}
              className="btn-primary w-full !py-2 text-sm disabled:opacity-40"
            >+ Add video</button>
          </div>
        </Panel>

        {videos.map((v) => (
          <Panel key={v.id}>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-forest/8 text-forest">▶</span>
                  <p className="font-medium text-forest-deep">{v.title}</p>
                  <span className="rounded-full bg-firefly/20 px-2 py-0.5 text-[10px] font-semibold capitalize text-firefly-deep">{v.kind}</span>
                </div>
                {v.description && <p className="mt-1 text-xs text-ink-soft">{v.description}</p>}
                {v.url && <a href={v.url} target="_blank" rel="noreferrer" className="mt-1 block truncate text-xs text-firefly-deep hover:underline">{v.url}</a>}
              </div>
              <button onClick={() => { if (confirm("Remove this video?")) removeVideo(v.id); }} className="shrink-0 text-xs font-semibold text-rose-600 hover:underline">Remove</button>
            </div>
          </Panel>
        ))}
      </div>

      {/* Intros */}
      <div className="space-y-4">
        <Panel>
          <h2 className="font-serif text-lg text-forest-deep">Short intros &amp; copy</h2>
          <p className="text-xs text-ink-faint">Reusable blurbs for socials, bios and pitches.</p>
          <div className="mt-3 space-y-2">
            <input className={input} placeholder="Title (e.g. Instagram bio)" value={iForm.title} onChange={(e) => setIForm((f) => ({ ...f, title: e.target.value }))} />
            <textarea className={input} rows={3} placeholder="The copy…" value={iForm.text} onChange={(e) => setIForm((f) => ({ ...f, text: e.target.value }))} />
            <button
              onClick={() => { if (iForm.title.trim() && iForm.text.trim()) { addIntro(iForm); setIForm({ title: "", text: "" }); } }}
              disabled={!iForm.title.trim() || !iForm.text.trim()}
              className="btn-primary w-full !py-2 text-sm disabled:opacity-40"
            >+ Add intro</button>
          </div>
        </Panel>

        {intros.map((i) => (
          <Panel key={i.id}>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <p className="text-xs font-semibold uppercase tracking-wide text-firefly-deep">{i.title}</p>
                <textarea
                  defaultValue={i.text}
                  rows={3}
                  onBlur={(e) => updateIntro(i.id, { text: e.target.value })}
                  className="mt-1 w-full resize-none rounded-lg border border-transparent bg-transparent p-1 text-sm text-ink-soft outline-none hover:border-firefly/20 focus:border-firefly focus:bg-white/60"
                />
                <button onClick={() => navigator.clipboard?.writeText(i.text)} className="text-xs font-semibold text-forest hover:underline">Copy</button>
              </div>
              <button onClick={() => { if (confirm("Remove this intro?")) removeIntro(i.id); }} className="shrink-0 text-xs font-semibold text-rose-600 hover:underline">Remove</button>
            </div>
          </Panel>
        ))}
      </div>
    </div>
  );
}
