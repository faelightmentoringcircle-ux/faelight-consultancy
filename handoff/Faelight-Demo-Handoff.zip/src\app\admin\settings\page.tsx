"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  getSettings, saveSettings, onStoreChange, calendarReady, activeCalendarAccount,
  CALENDAR_LABELS, Settings, CalendarProvider,
} from "@/lib/store";
import {
  getAllUsers, addUser, removeUser, updateUser, emailExists, isSeedUser,
  getUserModules, setUserModules, ADMIN_MODULES,
  useAuth, AdminUser, Role, DEMO_PASSWORD,
} from "@/lib/auth";
import { initials } from "@/lib/format";
import { AdminHeader, Panel } from "@/components/admin/ui";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function SettingsPage() {
  const { isAdmin, ready } = useAuth();
  const [s, setS] = useState<Settings | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const sync = () => setS(getSettings());
    sync();
    return onStoreChange(sync);
  }, []);

  if (!ready || !s) return null;
  if (!isAdmin) {
    return (
      <Panel className="mx-auto max-w-md text-center">
        <p className="text-2xl">✦</p>
        <h2 className="mt-2 font-serif text-xl text-forest-deep">Admins only</h2>
        <p className="mt-2 text-sm text-ink-soft">Settings are limited to admin accounts. Ask Maia if you need access.</p>
        <Link href="/admin" className="btn-primary mt-4">← Dashboard</Link>
      </Panel>
    );
  }

  const update = (patch: Partial<Settings>) => {
    saveSettings(patch);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  const toggleDay = (d: number) => {
    const days = s.workingDays.includes(d)
      ? s.workingDays.filter((x) => x !== d)
      : [...s.workingDays, d].sort();
    update({ workingDays: days });
  };

  return (
    <>
      <AdminHeader
        title="Settings"
        subtitle="Booking rules, calendar connection and team accounts."
        action={saved ? <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">Saved ✓</span> : undefined}
      />

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Booking rules */}
        <Panel>
          <h2 className="font-serif text-lg text-forest-deep">Booking rules</h2>
          <p className="text-xs text-ink-faint">Used by the public booking slot engine.</p>

          <div className="mt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-ink-faint">Working days</p>
            <div className="flex flex-wrap gap-1.5">
              {DAYS.map((d, i) => (
                <button
                  key={d}
                  onClick={() => toggleDay(i)}
                  className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                    s.workingDays.includes(i) ? "bg-forest text-parchment" : "bg-firefly/10 text-ink-faint hover:bg-firefly/20"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <NumberField label="Start hour" value={s.startHour} min={0} max={23} onChange={(v) => update({ startHour: v })} suffix=":00" />
            <NumberField label="End hour" value={s.endHour} min={1} max={24} onChange={(v) => update({ endHour: v })} suffix=":00" />
            <NumberField label="Buffer between (min)" value={s.bufferMin} min={0} max={60} step={5} onChange={(v) => update({ bufferMin: v })} />
            <NumberField label="Min notice (hours)" value={s.minNoticeHours} min={0} max={168} onChange={(v) => update({ minNoticeHours: v })} />
            <NumberField label="Max advance (days)" value={s.maxAdvanceDays} min={1} max={120} onChange={(v) => update({ maxAdvanceDays: v })} />
          </div>
          <p className="mt-3 text-xs text-ink-faint">All times in Asia/Manila (GMT+8).</p>
        </Panel>

        {/* Google connection */}
        <div className="space-y-6">
          <CalendarPanel s={s} update={update} />

          <Panel>
            <h2 className="font-serif text-lg text-forest-deep">Notifications & payment</h2>
            <div className="mt-3 space-y-3">
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Notify email (new leads & bookings)</label>
                <input
                  defaultValue={s.notifyEmail}
                  onBlur={(e) => update({ notifyEmail: e.target.value })}
                  className="w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Payment instructions (shown on booking confirmation)</label>
                <textarea
                  defaultValue={s.paymentInstructions}
                  rows={3}
                  onBlur={(e) => update({ paymentInstructions: e.target.value })}
                  className="w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly"
                />
              </div>
            </div>
          </Panel>
        </div>
      </div>

      {/* Team accounts */}
      <TeamAccounts />
    </>
  );
}

function CalendarPanel({
  s,
  update,
}: {
  s: Settings;
  update: (patch: Partial<Settings>) => void;
}) {
  const [connecting, setConnecting] = useState<CalendarProvider | null>(null);

  // Simulate an OAuth connect flow (Google / Microsoft).
  function connect(provider: "google" | "microsoft") {
    setConnecting(provider);
    setTimeout(() => {
      if (provider === "google") {
        update({
          googleConnected: true,
          googleAccount: s.googleAccount || "maia@faelight.ph",
          calendarProvider: "google",
        });
      } else {
        update({
          microsoftConnected: true,
          microsoftAccount: s.microsoftAccount || "maia@faelight.onmicrosoft.com",
          calendarProvider: "microsoft",
        });
      }
      setConnecting(null);
    }, 900);
  }

  const providers: {
    id: CalendarProvider;
    label: string;
    glyph: string;
    desc: string;
    connected: boolean;
    account: string;
  }[] = [
    {
      id: "default",
      label: "Faelight calendar",
      glyph: "✦",
      desc: "Built-in calendar — no account needed. Availability comes from your working hours and existing Faelight bookings.",
      connected: true,
      account: "Always available",
    },
    {
      id: "google",
      label: "Google Calendar",
      glyph: "G",
      desc: "Sync availability + create events with Meet links on your Google Calendar.",
      connected: s.googleConnected,
      account: s.googleAccount,
    },
    {
      id: "microsoft",
      label: "Microsoft / Teams",
      glyph: "⊞",
      desc: "Sync availability + create events with Teams links on your Outlook / Microsoft 365 calendar.",
      connected: s.microsoftConnected,
      account: s.microsoftAccount,
    },
  ];

  return (
    <Panel>
      <div className="flex items-center justify-between">
        <h2 className="font-serif text-lg text-forest-deep">Calendar</h2>
        <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${
          calendarReady(s) ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
        }`}>
          {calendarReady(s) ? "Booking live" : "Booking paused"}
        </span>
      </div>
      <p className="text-xs text-ink-faint">
        Choose which calendar drives public booking. Active: <strong className="text-forest">{CALENDAR_LABELS[s.calendarProvider]}</strong>
        {" · "}{activeCalendarAccount(s)}
      </p>

      <div className="mt-4 space-y-3">
        {providers.map((p) => {
          const active = s.calendarProvider === p.id;
          const linkable = p.id !== "default";
          return (
            <div
              key={p.id}
              className={`rounded-xl border p-3 transition ${
                active ? "border-forest bg-forest/5 ring-1 ring-forest/20" : "border-firefly/20"
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg text-sm font-bold ${
                  p.id === "default" ? "bg-gradient-to-br from-twilight to-forest text-firefly-bright"
                  : p.id === "google" ? "bg-white text-[#4285F4] ring-1 ring-firefly/20"
                  : "bg-[#464EB8] text-white"
                }`}>
                  {p.glyph}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-semibold text-forest-deep">{p.label}</p>
                    {p.connected && linkable && (
                      <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">● Connected</span>
                    )}
                    {active && (
                      <span className="rounded-full bg-firefly/20 px-2 py-0.5 text-[10px] font-semibold text-firefly-deep">Active</span>
                    )}
                  </div>
                  <p className="mt-0.5 text-xs text-ink-soft">{p.desc}</p>
                  {linkable && p.connected && (
                    <p className="mt-0.5 text-xs text-ink-faint">{p.account}</p>
                  )}

                  <div className="mt-2.5 flex flex-wrap gap-2">
                    {/* Use-this-calendar */}
                    {!active && (linkable ? p.connected : true) && (
                      <button
                        onClick={() => update({ calendarProvider: p.id })}
                        className="rounded-lg border border-forest/30 px-3 py-1.5 text-xs font-semibold text-forest hover:border-firefly"
                      >
                        Use this calendar
                      </button>
                    )}
                    {/* Connect / disconnect for linkable providers */}
                    {linkable && !p.connected && (
                      <button
                        onClick={() => connect(p.id as "google" | "microsoft")}
                        disabled={connecting === p.id}
                        className="btn-primary !px-3 !py-1.5 text-xs disabled:opacity-60"
                      >
                        {connecting === p.id ? "Connecting…" : `Connect ${p.label}`}
                      </button>
                    )}
                    {linkable && p.connected && (
                      <button
                        onClick={() => {
                          const patch: Partial<Settings> = p.id === "google"
                            ? { googleConnected: false }
                            : { microsoftConnected: false };
                          // if disconnecting the active calendar, fall back to default
                          if (active) patch.calendarProvider = "default";
                          update(patch);
                        }}
                        className="rounded-lg border border-rose-200 px-3 py-1.5 text-xs font-semibold text-rose-600 hover:bg-rose-50"
                      >
                        Disconnect
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <p className="mt-3 text-xs text-ink-faint">
        If the active calendar is a disconnected provider, the public{" "}
        <Link href="/book" className="text-firefly-deep hover:underline">/book</Link> page degrades to the
        inquiry form. In production, Connect runs the provider's OAuth flow (Google: calendar.readonly +
        calendar.events; Microsoft Graph: Calendars.ReadWrite).
      </p>
    </Panel>
  );
}

function TeamAccounts() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", title: "", role: "team" as Role });
  const [error, setError] = useState("");

  useEffect(() => {
    const sync = () => setUsers(getAllUsers());
    sync();
    window.addEventListener("fae:auth", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("fae:auth", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!form.name.trim() || !form.email.trim()) { setError("Name and email are required."); return; }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email.trim())) { setError("Enter a valid email."); return; }
    if (emailExists(form.email)) { setError("That email already has an account."); return; }
    addUser({
      name: form.name.trim(),
      email: form.email.trim(),
      title: form.title.trim() || (form.role === "admin" ? "Admin" : "Team member"),
      role: form.role,
    });
    setForm({ name: "", email: "", title: "", role: "team" });
    setAdding(false);
  }

  const inputCls = "w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly";

  return (
    <Panel className="mt-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-serif text-lg text-forest-deep">Team accounts</h2>
          <p className="text-xs text-ink-faint">Admins manage everything; team members manage leads & bookings.</p>
        </div>
        {!adding && (
          <button onClick={() => setAdding(true)} className="btn-primary !px-4 !py-2 text-sm">
            + Add user
          </button>
        )}
      </div>

      {adding && (
        <form onSubmit={submit} className="mt-4 rounded-xl border border-firefly/25 bg-parchment-warm/50 p-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Name<span className="text-firefly-deep">*</span></label>
              <input className={inputCls} value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="Full name" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Email<span className="text-firefly-deep">*</span></label>
              <input type="email" className={inputCls} value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="name@faelight.ph" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Title / role label</label>
              <input className={inputCls} value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} placeholder="e.g. Bookkeeper" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">Access level</label>
              <select className={inputCls} value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value as Role }))}>
                <option value="team">Team — leads & bookings</option>
                <option value="admin">Admin — full access</option>
              </select>
            </div>
          </div>
          {error && <p className="mt-2 text-xs font-semibold text-rose-600">{error}</p>}
          <p className="mt-3 text-xs text-ink-faint">
            New accounts sign in with the shared demo password <code className="font-mono font-semibold text-forest">{DEMO_PASSWORD}</code>.
            In production you'd email an invite instead.
          </p>
          <div className="mt-3 flex gap-2">
            <button type="submit" className="btn-primary !px-4 !py-2 text-sm">Create account</button>
            <button type="button" onClick={() => { setAdding(false); setError(""); }} className="btn-ghost !px-4 !py-2 text-sm">Cancel</button>
          </div>
        </form>
      )}

      <div className="mt-4 space-y-3">
        {users.map((u) => {
          const seed = isSeedUser(u.id);
          return (
            <div key={u.id} className="rounded-xl border border-firefly/15 p-3">
              <div className="flex items-center gap-3">
                <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-forest/8 text-xs font-semibold text-forest">
                  {initials(u.name)}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-forest-deep">{u.name}</p>
                  <p className="truncate text-xs text-ink-faint">{u.title}</p>
                </div>
                {seed ? (
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold capitalize ${
                    u.role === "admin" ? "bg-firefly/20 text-firefly-deep" : "bg-forest/10 text-forest"
                  }`}>
                    {u.role}
                  </span>
                ) : (
                  <div className="flex shrink-0 items-center gap-1.5">
                    <select
                      value={u.role}
                      onChange={(e) => updateUser(u.id, { role: e.target.value as Role })}
                      className="rounded-md border border-firefly/25 bg-white/70 px-1.5 py-1 text-[10px] font-semibold capitalize outline-none focus:border-firefly"
                      aria-label={`Role for ${u.name}`}
                    >
                      <option value="team">team</option>
                      <option value="admin">admin</option>
                    </select>
                    <button
                      onClick={() => { if (confirm(`Remove ${u.name}'s account?`)) removeUser(u.id); }}
                      className="rounded-md border border-rose-200 px-1.5 py-1 text-[10px] font-semibold text-rose-600 hover:bg-rose-50"
                      aria-label={`Remove ${u.name}`}
                    >
                      Remove
                    </button>
                  </div>
                )}
              </div>

              {u.role === "admin" ? (
                <p className="mt-2 pl-12 text-xs text-firefly-deep">✦ Full access to every section.</p>
              ) : (
                <AccessEditor user={u} />
              )}
            </div>
          );
        })}
      </div>
      <p className="mt-3 text-xs text-ink-faint">
        The 7 founding accounts are protected. Team members only see the sections you assign here.
      </p>
    </Panel>
  );
}

function AccessEditor({ user }: { user: AdminUser }) {
  const [mods, setMods] = useState<string[]>([]);
  useEffect(() => { setMods(getUserModules(user)); }, [user.id]);

  function toggle(key: string) {
    const next = mods.includes(key) ? mods.filter((m) => m !== key) : [...mods, key];
    setMods(next);
    setUserModules(user.id, next);
  }

  return (
    <div className="mt-3 border-t border-firefly/12 pt-3">
      <p className="mb-2 text-[10px] font-semibold uppercase tracking-wide text-ink-faint">
        Section access — assign what {user.name.split(" ")[0]} can open
      </p>
      <div className="flex flex-wrap gap-1.5">
        {ADMIN_MODULES.map((m) => {
          const on = mods.includes(m.key);
          return (
            <button
              key={m.key}
              onClick={() => toggle(m.key)}
              className={`rounded-full border px-2.5 py-1 text-[11px] font-medium transition ${
                on ? "border-forest bg-forest text-parchment" : "border-firefly/25 text-ink-soft hover:border-firefly"
              }`}
            >
              {on ? "✓ " : ""}{m.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function NumberField({
  label, value, onChange, min, max, step = 1, suffix,
}: {
  label: string; value: number; onChange: (v: number) => void;
  min?: number; max?: number; step?: number; suffix?: string;
}) {
  return (
    <div>
      <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">{label}</label>
      <div className="flex items-center gap-1">
        <input
          type="number"
          value={value}
          min={min}
          max={max}
          step={step}
          onChange={(e) => onChange(Number(e.target.value))}
          className="w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly"
        />
        {suffix && <span className="text-xs text-ink-faint">{suffix}</span>}
      </div>
    </div>
  );
}
