"use client";

import { useEffect, useState } from "react";
import { CATEGORIES, SERVICES, servicesByCategory } from "@/lib/content";
import {
  getServiceOverrides, saveServiceOverride, resetServiceOverrides,
  onStoreChange, ServiceOverride,
} from "@/lib/store";
import { AdminHeader, Panel } from "@/components/admin/ui";

export default function ServicesAdminPage() {
  const [overrides, setOverrides] = useState<Record<string, ServiceOverride>>({});
  const [editing, setEditing] = useState<string | null>(null);

  useEffect(() => {
    const sync = () => setOverrides(getServiceOverrides());
    sync();
    return onStoreChange(sync);
  }, []);

  return (
    <>
      <AdminHeader
        title="Services & pricing"
        subtitle="Edit descriptions, prices and availability. Content lives in the database — not hardcoded."
        action={
          Object.keys(overrides).length > 0 ? (
            <button
              onClick={() => { if (confirm("Revert all service edits to the seeded content?")) resetServiceOverrides(); }}
              className="btn-ghost !px-4 !py-2 text-sm"
            >
              ↺ Revert all edits
            </button>
          ) : undefined
        }
      />

      <div className="mb-6 rounded-xl border border-firefly/25 bg-firefly/8 p-4 text-sm text-ink-soft">
        <span className="font-semibold text-forest-deep">✦ Demo note:</span> edits save to your
        local working copy. In production they write to Supabase and flow to the public pages,
        pricing menu and PDF brochures automatically.
      </div>

      <div className="space-y-8">
        {CATEGORIES.map((cat) => (
          <div key={cat.slug}>
            <h2 className="mb-3 font-serif text-xl text-forest-deep">
              <span className="text-firefly">✦</span> {cat.name}
            </h2>
            <div className="space-y-3">
              {servicesByCategory(cat.slug).map((s) => {
                const o = overrides[s.id] ?? {};
                const merged = {
                  priceLabel: o.priceLabel ?? s.priceLabel,
                  description: o.description ?? s.description,
                  bestFor: o.bestFor ?? s.bestFor,
                  active: o.active ?? true,
                };
                const edited = Object.keys(o).length > 0;
                const isOpen = editing === s.id;
                return (
                  <Panel key={s.id} className={merged.active ? "" : "opacity-60"}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0">
                        <p className="font-medium text-forest-deep">
                          {s.name}
                          {edited && <span className="ml-2 rounded-full bg-firefly/20 px-2 py-0.5 text-[10px] font-semibold text-firefly-deep">edited</span>}
                          {!merged.active && <span className="ml-2 rounded-full bg-stone-200 px-2 py-0.5 text-[10px] font-semibold text-stone-600">hidden</span>}
                        </p>
                        {!isOpen && (
                          <>
                            <p className="mt-1 text-sm text-ink-soft">{merged.description}</p>
                            <p className="mt-1 text-xs text-ink-faint">Best for: {merged.bestFor}</p>
                          </>
                        )}
                      </div>
                      <div className="flex shrink-0 items-center gap-3">
                        <span className="whitespace-nowrap font-semibold text-firefly-deep">{merged.priceLabel}</span>
                        <button
                          onClick={() => setEditing(isOpen ? null : s.id)}
                          className="rounded-lg border border-firefly/25 px-3 py-1.5 text-xs font-semibold text-forest hover:border-firefly"
                        >
                          {isOpen ? "Close" : "Edit"}
                        </button>
                      </div>
                    </div>

                    {isOpen && (
                      <div className="mt-4 grid gap-3 border-t border-firefly/15 pt-4">
                        <FieldRow label="Price label">
                          <input
                            defaultValue={merged.priceLabel}
                            onBlur={(e) => saveServiceOverride(s.id, { priceLabel: e.target.value })}
                            className="w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly"
                          />
                        </FieldRow>
                        <FieldRow label="Description">
                          <textarea
                            defaultValue={merged.description}
                            rows={2}
                            onBlur={(e) => saveServiceOverride(s.id, { description: e.target.value })}
                            className="w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly"
                          />
                        </FieldRow>
                        <FieldRow label="Best for">
                          <input
                            defaultValue={merged.bestFor}
                            onBlur={(e) => saveServiceOverride(s.id, { bestFor: e.target.value })}
                            className="w-full rounded-lg border border-firefly/25 bg-white/70 px-3 py-2 text-sm outline-none focus:border-firefly"
                          />
                        </FieldRow>
                        <label className="flex items-center gap-2 text-sm text-ink-soft">
                          <input
                            type="checkbox"
                            checked={merged.active}
                            onChange={(e) => saveServiceOverride(s.id, { active: e.target.checked })}
                            className="h-4 w-4 rounded border-firefly/40 text-forest focus:ring-firefly"
                          />
                          Active (shown on the public site)
                        </label>
                        <p className="text-xs text-ink-faint">Changes save automatically when you click away.</p>
                      </div>
                    )}
                  </Panel>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function FieldRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-ink-faint">{label}</label>
      {children}
    </div>
  );
}
