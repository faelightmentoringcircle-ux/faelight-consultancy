// =====================================================================
// Demo auth. Stands in for Supabase Auth + profiles (spec §3/§8).
// Roles: admin (Maia + owner) can see everything; team (Sassa, Kenny,
// Kits, Dor, Josh) can manage leads & bookings but not settings/accounts.
// A single shared demo password unlocks any account.
// =====================================================================
"use client";

import { useEffect, useState } from "react";

export type Role = "admin" | "team";

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  title: string;
}

export const DEMO_PASSWORD = "faelight-demo";

// Seed accounts (the founding team). These can't be removed. Additional
// accounts created from Settings → Team accounts persist in localStorage.
// In production this is the Supabase `profiles` table.
export const SEED_USERS: AdminUser[] = [
  { id: "u-maia", name: "Maia Castañeda", email: "maia@faelight.ph", role: "admin", title: "Founder" },
  { id: "u-berly", name: "Berly", email: "berly@faelight.ph", role: "admin", title: "Systems & Process Lead" },
  { id: "u-owner", name: "Owner", email: "owner@faelight.ph", role: "admin", title: "Owner / Admin" },
  { id: "u-sassa", name: "Sassa", email: "sassa@faelight.ph", role: "team", title: "Executive VA" },
  { id: "u-kenny", name: "Kenny", email: "kenny@faelight.ph", role: "team", title: "Operations" },
  { id: "u-kits", name: "Kits", email: "kits@faelight.ph", role: "team", title: "Marketing" },
  { id: "u-dor", name: "Dor", email: "dor@faelight.ph", role: "team", title: "Admin & Experiences" },
  { id: "u-josh", name: "Josh", email: "josh@faelight.ph", role: "team", title: "SEO & Web" },
];

const KEY = "fae.session.v1";
const USERS_KEY = "fae.users.v1";

export function isSeedUser(id: string): boolean {
  return SEED_USERS.some((u) => u.id === id);
}

function readCustomUsers(): AdminUser[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]") as AdminUser[];
  } catch {
    return [];
  }
}
function writeCustomUsers(users: AdminUser[]) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
  window.dispatchEvent(new CustomEvent("fae:auth"));
}

// The full account list = seed team + any added accounts.
export function getAllUsers(): AdminUser[] {
  return [...SEED_USERS, ...readCustomUsers()];
}

export function addUser(input: Omit<AdminUser, "id">): AdminUser {
  const user: AdminUser = {
    ...input,
    id: `u-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
  };
  writeCustomUsers([...readCustomUsers(), user]);
  return user;
}

export function updateUser(id: string, patch: Partial<Omit<AdminUser, "id">>) {
  if (isSeedUser(id)) return; // seed accounts are read-only in the demo
  writeCustomUsers(
    readCustomUsers().map((u) => (u.id === id ? { ...u, ...patch } : u))
  );
}

export function removeUser(id: string) {
  if (isSeedUser(id)) return;
  writeCustomUsers(readCustomUsers().filter((u) => u.id !== id));
}

export function emailExists(email: string): boolean {
  const e = email.trim().toLowerCase();
  return getAllUsers().some((u) => u.email.toLowerCase() === e);
}

// --- Per-section (module) access assignment --------------------------
// Admins see everything. Team members see the modules assigned to them
// (default: dashboard, leads, bookings) — admins assign more in Settings.
export const ADMIN_MODULES: { key: string; label: string }[] = [
  { key: "dashboard", label: "Dashboard" },
  { key: "leads", label: "Leads" },
  { key: "bookings", label: "Bookings" },
  { key: "payments", label: "Payments" },
  { key: "calendar", label: "Calendar" },
  { key: "marketing", label: "Marketing" },
  { key: "reviews", label: "Reviews" },
  { key: "services", label: "Services" },
];
const DEFAULT_TEAM_MODULES = ["dashboard", "leads", "bookings"];
// Sensible role-based defaults for the founding team (admin can change these).
const SEED_TEAM_MODULES: Record<string, string[]> = {
  "u-sassa": ["dashboard", "leads", "bookings", "calendar"],
  "u-kenny": ["dashboard", "leads", "bookings", "payments", "calendar"],
  "u-kits": ["dashboard", "marketing", "reviews"],
  "u-dor": ["dashboard", "leads", "bookings", "calendar"],
  "u-josh": ["dashboard", "marketing", "services", "reviews"],
};
const ACCESS_KEY = "fae.moduleaccess.v1";

function readAccess(): Record<string, string[]> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(localStorage.getItem(ACCESS_KEY) || "{}") as Record<string, string[]>;
  } catch {
    return {};
  }
}

// The module keys a user may access.
export function getUserModules(user: AdminUser | null): string[] {
  if (!user) return [];
  if (user.role === "admin") return [...ADMIN_MODULES.map((m) => m.key), "settings"];
  return readAccess()[user.id] ?? SEED_TEAM_MODULES[user.id] ?? DEFAULT_TEAM_MODULES;
}
export function setUserModules(userId: string, modules: string[]) {
  const all = readAccess();
  all[userId] = modules;
  localStorage.setItem(ACCESS_KEY, JSON.stringify(all));
  window.dispatchEvent(new CustomEvent("fae:auth"));
}
export function canAccessModule(user: AdminUser | null, key: string): boolean {
  return getUserModules(user).includes(key);
}

export function currentUser(): AdminUser | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return null;
    const id = JSON.parse(raw) as string;
    return getAllUsers().find((u) => u.id === id) ?? null;
  } catch {
    return null;
  }
}

export function login(userId: string) {
  localStorage.setItem(KEY, JSON.stringify(userId));
  window.dispatchEvent(new CustomEvent("fae:auth"));
}

export function logout() {
  localStorage.removeItem(KEY);
  window.dispatchEvent(new CustomEvent("fae:auth"));
}

// React hook — re-renders on login/logout.
export function useAuth() {
  const [user, setUser] = useState<AdminUser | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const sync = () => setUser(currentUser());
    sync();
    setReady(true);
    window.addEventListener("fae:auth", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("fae:auth", sync);
      window.removeEventListener("storage", sync);
    };
  }, []);

  return { user, ready, isAdmin: user?.role === "admin" };
}
