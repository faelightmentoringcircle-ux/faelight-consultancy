import type { Metadata } from "next";
import Link from "next/link";
import { BRAND, CATEGORIES, servicesByCategory } from "@/lib/content";
import { Eyebrow, Fireflies, Glow, Star } from "@/components/Motifs";
import { ClientFit, CtaBand } from "@/components/Sections";

export const metadata: Metadata = {
  title: "Service & Pricing Menu",
  description:
    "The full Faelight service and pricing menu — Mentoring Circle, Systems and Experiences. Final pricing depends on scope, audience and delivery needs.",
};

export default function PricingPage() {
  return (
    <>
      <section className="starfield relative overflow-hidden bg-enchanted text-parchment">
        <Fireflies count={14} />
        <Glow className="-left-16 top-4" size={480} />
        <div className="container-fae relative z-10 py-16 text-center sm:py-20">
          <Eyebrow light>Service & pricing menu</Eyebrow>
          <h1 className="mx-auto mt-4 max-w-2xl font-serif text-3xl leading-tight sm:text-4xl">
            Everything we offer, in one place.
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-parchment/75">
            Three columns of work — training, systems and experiences. Prices
            are starting points; every engagement is shaped around you.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container-fae">
          <div className="grid gap-8 lg:grid-cols-3 lg:items-start">
            {CATEGORIES.map((cat) => (
              <div key={cat.slug} className="flex flex-col">
                <div className="rounded-t-2xl bg-enchanted p-6 text-center text-parchment">
                  <p className="text-xs font-semibold uppercase tracking-eyebrow text-firefly-bright">
                    {cat.audience}
                  </p>
                  <h2 className="mt-2 font-serif text-2xl">
                    <Star className="mr-1.5 text-base text-firefly-bright" />
                    {cat.name}
                  </h2>
                  <p className="mt-2 text-sm text-parchment/70">{cat.tagline}</p>
                </div>
                <div className="flex-1 space-y-3 rounded-b-2xl border border-t-0 border-firefly/20 bg-parchment-card p-5 shadow-card">
                  {servicesByCategory(cat.slug).map((s) => (
                    <div key={s.id} className="border-b border-firefly/12 pb-3 last:border-0 last:pb-0">
                      <div className="flex items-start justify-between gap-3">
                        <p className="font-semibold text-forest-deep">{s.name}</p>
                        <span className="whitespace-nowrap text-sm font-semibold text-firefly-deep">
                          {s.priceLabel}
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-ink-soft">{s.description}</p>
                      {s.isBookable && (
                        <Link href="/book" className="mt-1 inline-block text-xs font-semibold text-forest hover:underline">
                          Bookable online →
                        </Link>
                      )}
                    </div>
                  ))}
                  <Link href={`/${cat.slug}`} className="btn-ghost mt-2 w-full">
                    View {cat.name} page
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <p className="mt-10 text-center text-sm italic text-ink-faint">
            {BRAND.pricingDisclaimer}
          </p>
        </div>
      </section>

      <ClientFit />
      <CtaBand
        heading="Not sure which column is yours?"
        sub="Book a discovery call — we'll help you find the next right step, no pressure."
      />
    </>
  );
}
