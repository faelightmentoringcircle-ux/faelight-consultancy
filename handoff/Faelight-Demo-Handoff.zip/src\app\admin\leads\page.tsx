"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { getLeads, onStoreChange, Lead, LEAD_STATUSES, LeadStatus } from "@/lib/store";
import { CATEGORIES, SERVICES } from "@/lib/content";
import { relativeDay } from "@/lib/format";
import { AdminHeader, Panel, LeadBadge, CategoryTag } from "@/components/admin/ui";

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [status, setStatus] = useState<LeadStatus | "all">("all");
  const [cat, setCat] = useState<string>("all");
  const [q, setQ] = useState("");

  useEffect(() => {
    const sync = () => setLeads(getLeads());
    sync();
    return onStoreChange(sync);
  }, []);

  const filtered = useMemo(() => {
    return leads.filter((l) => {
      if (status !== "all" && l.status !== status) return false;
      if (cat !== "all" && l.categorySlug !== cat) return false;
      if (q) {
        const hay = `${l.name} ${l.email} ${l.company ?? ""} ${l.message}`.toLowerCase();
        if (!hay.includes(q.toLowerCase())) return false;
      }
      return true;
    });
  }, [leads, status, cat, q]);

  const counts = LEAD_STATUSES.reduce<Record<string, number>>((acc, s) => {
    acc[s] = leads.filter((l) => l.status === s).length;
    return acc;
  }, {});

  return (
    <>
      <AdminHeader
        title="Leads"
        subtitle={`${leads.length} total · ${filtered.length} shown`}
        action={
          <div className="rounded-xl border border-firefly/25 bg-parchment-card px-4 py-2 text-center">
            <p className="font-serif text-xl text-forest">{leads.filter((l) => l.agreedToUpdates).length}</p>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-ink-faint">on mailing list</p>
          </div>
        }
      />

      {/* Status filter chips */}
      <div className="mb-4 flex flex-wrap gap-2">
        <Chip active={status === "all"} onClick={() => setStatus("all")}>All · {leads.length}</Chip>
        {LEAD_STATUSES.map((s) => (
          <Chip key={s} active={status === s} onClick={() => setStatus(s)}>
            <span className="capitalize">{s}</span> · {counts[s]}
          </Chip>
        ))}
      </div>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search name, email, company, message…"
          className="flex-1 rounded-xl border border-firefly/25 bg-parchment-card px-4 py-2.5 text-sm outline-none focus:border-firefly"
        />
        <select
          value={cat}
          onChange={(e) => setCat(e.target.value)}
          className="rounded-xl border border-firefly/25 bg-parchment-card px-4 py-2.5 text-sm outline-none focus:border-firefly"
        >
          <option value="all">All sub-brands</option>
          {CATEGORIES.map((c) => (<option key={c.slug} value={c.slug}>{c.name}</option>))}
        </select>
      </div>

      <Panel className="!p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="border-b border-firefly/20 text-left text-xs uppercase tracking-wide text-ink-faint">
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Interest</th>
                <th className="px-4 py-3">Source</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Received</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((l) => {
                const svc = SERVICES.find((s) => s.id === l.serviceId);
                return (
                  <tr key={l.id} className="border-b border-firefly/10 transition hover:bg-firefly/5">
                    <td className="px-4 py-3">
                      <Link href={`/admin/leads/view?id=${l.id}`} className="font-medium text-forest-deep hover:underline">
                        {l.name}
                      </Link>
                      <p className="text-xs text-ink-faint">{l.company || l.email}</p>
                    </td>
                    <td className="px-4 py-3">
                      <CategoryTag slug={l.categorySlug} />
                      {svc && <p className="mt-1 text-xs text-ink-faint">{svc.name}</p>}
                    </td>
                    <td className="px-4 py-3 text-ink-soft">
                      {l.source}
                      {l.utmSource && <p className="text-[11px] text-firefly-deep">utm: {l.utmSource}</p>}
                    </td>
                    <td className="px-4 py-3"><LeadBadge status={l.status} /></td>
                    <td className="px-4 py-3 text-ink-soft">{relativeDay(l.createdAt)}</td>
                    <td className="px-4 py-3 text-right">
                      <Link href={`/admin/leads/view?id=${l.id}`} className="text-xs font-semibold text-firefly-deep hover:underline">
                        Open →
                      </Link>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="px-4 py-10 text-center text-ink-faint">No leads match these filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
        active ? "border-forest bg-forest text-parchment" : "border-firefly/25 bg-parchment-card text-ink-soft hover:border-firefly"
      }`}
    >
      {children}
    </button>
  );
}
