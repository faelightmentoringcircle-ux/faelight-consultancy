// =====================================================================
// Demo data store — persists in localStorage. Mirrors the leads /
// lead_notes / bookings / settings tables from spec §8. In production
// these are Supabase tables written via server actions.
// =====================================================================
"use client";

import { CategorySlug } from "./content";

export type LeadStatus =
  | "new"
  | "contacted"
  | "discovery booked"
  | "proposal sent"
  | "won"
  | "lost";

export const LEAD_STATUSES: LeadStatus[] = [
  "new",
  "contacted",
  "discovery booked",
  "proposal sent",
  "won",
  "lost",
];

export type BookingStatus = "confirmed" | "completed" | "cancelled" | "no-show";
// unpaid → submitted (client uploaded proof) → paid (verified by admin) / waived
export type PaymentStatus = "unpaid" | "submitted" | "paid" | "waived";

export interface Lead {
  id: string;
  name: string;
  email: string;
  phone?: string;
  company?: string;
  categorySlug?: CategorySlug | null;
  serviceId?: string | null;
  message: string;
  source: string; // "how did you hear"
  utmSource?: string;
  utmMedium?: string;
  utmCampaign?: string;
  agreedToUpdates: boolean;
  status: LeadStatus;
  createdAt: string;
}

export interface LeadNote {
  id: string;
  leadId: string;
  author: string;
  note: string;
  createdAt: string;
}

export interface Booking {
  id: string;
  leadId: string | null;
  bookingTypeId: string;
  bookingTypeName: string;
  startsAt: string;
  endsAt: string;
  clientName: string;
  clientEmail: string;
  clientPhone?: string;
  agenda: string;
  meetLink: string;
  status: BookingStatus;
  feeLabel?: string; // e.g. "₱2,500 — payable after confirmation"
  paymentStatus?: PaymentStatus;
  amountPaid?: number;
  paymentMethod?: string; // GCash / bank transfer / cash
  paidAt?: string;
  proofUrl?: string; // data: URL of the client's proof-of-payment screenshot
  proofSubmittedAt?: string;
  verifiedBy?: string; // admin who confirmed the payment
  createdAt: string;
}

export type CalendarProvider = "default" | "google" | "microsoft";

export interface Settings {
  workingDays: number[]; // 0=Sun..6=Sat
  startHour: number; // 10
  endHour: number; // 18
  bufferMin: number; // 15
  minNoticeHours: number; // 24
  maxAdvanceDays: number; // 30
  blockedDates: string[]; // specific YYYY-MM-DD days the admin marked off
  paymentInstructions: string;
  // Payment collection (shown to clients on booking; settle before session)
  requirePaymentBeforeSession: boolean;
  payGcashName: string;
  payGcashNumber: string;
  payGcashQr: string; // data: URL of the GCash / e-wallet QR image
  payBankName: string;
  payBankAccountName: string;
  payBankAccountNumber: string;
  notifyEmail: string;
  // Which calendar drives booking availability + event creation.
  calendarProvider: CalendarProvider;
  googleConnected: boolean;
  googleAccount: string;
  microsoftConnected: boolean;
  microsoftAccount: string;
}

export const CALENDAR_LABELS: Record<CalendarProvider, string> = {
  default: "Faelight calendar",
  google: "Google Calendar",
  microsoft: "Microsoft / Teams",
};

// Is the active calendar usable for public booking? The built-in "default"
// calendar always is; a linked provider must actually be connected.
export function calendarReady(s: Settings): boolean {
  if (s.calendarProvider === "google") return s.googleConnected;
  if (s.calendarProvider === "microsoft") return s.microsoftConnected;
  return true; // default
}

export function activeCalendarAccount(s: Settings): string {
  if (s.calendarProvider === "google") return s.googleAccount;
  if (s.calendarProvider === "microsoft") return s.microsoftAccount;
  return "Built-in Faelight calendar";
}

const KEYS = {
  leads: "fae.leads.v1",
  notes: "fae.notes.v1",
  bookings: "fae.bookings.v1",
  settings: "fae.settings.v1",
  services: "fae.services.v1",
  events: "fae.events.v1",
  campaigns: "fae.campaigns.v1",
  social: "fae.social.v1",
  videos: "fae.videos.v1",
  intros: "fae.intros.v1",
  automations: "fae.automations.v1",
  reviews: "fae.reviews.v1",
  brands: "fae.brands.v1",
  seeded: "fae.seeded.v1",
};

export const BRAND_GROUPS = [
  "Training & Mentorship",
  "Executive & Admin Support",
  "Operations & Business Systems",
  "Marketing",
];

// Service content overrides (spec §3/§8: services editable from /admin/services).
// In the demo these persist locally; in production they write to Supabase and
// flow through to the public pages + PDFs.
export interface ServiceOverride {
  priceLabel?: string;
  description?: string;
  bestFor?: string;
  active?: boolean;
}

export function getServiceOverrides(): Record<string, ServiceOverride> {
  return read<Record<string, ServiceOverride>>(KEYS.services, {});
}
export function saveServiceOverride(id: string, patch: ServiceOverride) {
  const all = getServiceOverrides();
  write(KEYS.services, { ...all, [id]: { ...all[id], ...patch } });
}
export function resetServiceOverrides() {
  write(KEYS.services, {});
}

export const DEFAULT_SETTINGS: Settings = {
  workingDays: [1, 2, 3, 4, 5],
  startHour: 10,
  endHour: 18,
  bufferMin: 15,
  minNoticeHours: 24,
  maxAdvanceDays: 30,
  blockedDates: [],
  paymentInstructions:
    "Please settle your booking fee before your session using the details below, then send your proof of payment to faelightmentoringcircle@gmail.com. Your slot is reserved once payment is confirmed.",
  requirePaymentBeforeSession: true,
  payGcashName: "Maria Castañeda",
  payGcashNumber: "0917 892 1280",
  payGcashQr: "",
  payBankName: "BPI",
  payBankAccountName: "Maria Castañeda",
  payBankAccountNumber: "1234-5678-90",
  notifyEmail: "faelightmentoringcircle@gmail.com",
  calendarProvider: "google", // demo links Google out of the box
  googleConnected: true,
  googleAccount: "maia@faelight.ph",
  microsoftConnected: false,
  microsoftAccount: "",
};

// --- low-level helpers -----------------------------------------------
function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new CustomEvent("fae:store"));
}

export function onStoreChange(cb: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  const handler = () => cb();
  window.addEventListener("fae:store", handler);
  window.addEventListener("storage", handler);
  return () => {
    window.removeEventListener("fae:store", handler);
    window.removeEventListener("storage", handler);
  };
}

export function uid(prefix = "id"): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random()
    .toString(36)
    .slice(2, 7)}`;
}

// --- Settings --------------------------------------------------------
export function getSettings(): Settings {
  return { ...DEFAULT_SETTINGS, ...read<Partial<Settings>>(KEYS.settings, {}) };
}
export function saveSettings(patch: Partial<Settings>) {
  write(KEYS.settings, { ...getSettings(), ...patch });
}

// --- Leads -----------------------------------------------------------
export function getLeads(): Lead[] {
  ensureSeed();
  return read<Lead[]>(KEYS.leads, []).sort(
    (a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)
  );
}

export function addLead(
  input: Omit<Lead, "id" | "createdAt" | "status"> & { status?: LeadStatus }
): Lead {
  const lead: Lead = {
    ...input,
    id: uid("lead"),
    status: input.status ?? "new",
    createdAt: new Date().toISOString(),
  };
  const all = read<Lead[]>(KEYS.leads, []);
  write(KEYS.leads, [lead, ...all]);
  return lead;
}

export function updateLead(id: string, patch: Partial<Lead>) {
  const all = read<Lead[]>(KEYS.leads, []);
  write(
    KEYS.leads,
    all.map((l) => (l.id === id ? { ...l, ...patch } : l))
  );
}

export function getLead(id: string): Lead | undefined {
  return getLeads().find((l) => l.id === id);
}

// --- Notes -----------------------------------------------------------
export function getNotes(leadId: string): LeadNote[] {
  return read<LeadNote[]>(KEYS.notes, [])
    .filter((n) => n.leadId === leadId)
    .sort((a, b) => +new Date(a.createdAt) - +new Date(b.createdAt));
}
export function addNote(leadId: string, author: string, note: string): LeadNote {
  const n: LeadNote = {
    id: uid("note"),
    leadId,
    author,
    note,
    createdAt: new Date().toISOString(),
  };
  write(KEYS.notes, [...read<LeadNote[]>(KEYS.notes, []), n]);
  return n;
}

// --- Bookings --------------------------------------------------------
export function getBookings(): Booking[] {
  ensureSeed();
  return read<Booking[]>(KEYS.bookings, []).sort(
    (a, b) => +new Date(a.startsAt) - +new Date(b.startsAt)
  );
}

export function addBooking(
  input: Omit<Booking, "id" | "createdAt" | "status" | "meetLink"> & {
    status?: BookingStatus;
  }
): Booking {
  const booking: Booking = {
    ...input,
    id: uid("bk"),
    status: input.status ?? "confirmed",
    paymentStatus: input.paymentStatus ?? "unpaid",
    meetLink: conferenceLink(getSettings().calendarProvider),
    createdAt: new Date().toISOString(),
  };
  write(KEYS.bookings, [...read<Booking[]>(KEYS.bookings, []), booking]);
  // Booking blocks the calendar on the linked/default provider too (sync).
  return booking;
}

// Video-conferencing link that matches the active calendar provider.
function conferenceLink(provider: CalendarProvider): string {
  const chunk = (n: number) => Math.random().toString(36).slice(2, 2 + n);
  if (provider === "microsoft")
    return `https://teams.microsoft.com/l/meetup-join/${chunk(8)}-${chunk(4)}`;
  if (provider === "google")
    return `https://meet.google.com/${chunk(3)}-${chunk(4)}-${chunk(3)}`;
  return `https://meet.faelight.ph/${chunk(6)}`; // built-in room
}

export function updateBooking(id: string, patch: Partial<Booking>) {
  const all = read<Booking[]>(KEYS.bookings, []);
  write(
    KEYS.bookings,
    all.map((b) => (b.id === id ? { ...b, ...patch } : b))
  );
}

// --- Calendar events (personal holds + synced external events) -------
// One shared collection is the source of truth. Each event is tagged with
// the calendar it came from, which is what makes sync bidirectional:
// an "app" hold shows on the linked calendar; a synced "google"/"microsoft"
// event shows in the app. All of them block public booking availability.
export type EventSource = "app" | "google" | "microsoft";

export interface CalendarEvent {
  id: string;
  date: string; // YYYY-MM-DD (local)
  startMin: number; // minutes from midnight; 0 + endMin 1440 = all day
  endMin: number;
  title: string;
  source: EventSource;
  allDay: boolean;
}

// Local YYYY-MM-DD (avoids UTC off-by-one from toISOString()).
export function ymd(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

export function getEvents(): CalendarEvent[] {
  ensureSeed();
  return read<CalendarEvent[]>(KEYS.events, []);
}
export function getEventsForDate(date: Date): CalendarEvent[] {
  const key = ymd(date);
  return getEvents()
    .filter((e) => e.date === key)
    .sort((a, b) => a.startMin - b.startMin);
}
export function addEvent(input: Omit<CalendarEvent, "id">): CalendarEvent {
  const ev: CalendarEvent = { ...input, id: uid("ev") };
  write(KEYS.events, [...read<CalendarEvent[]>(KEYS.events, []), ev]);
  return ev;
}
export function removeEvent(id: string) {
  write(
    KEYS.events,
    read<CalendarEvent[]>(KEYS.events, []).filter((e) => e.id !== id)
  );
}

// --- Blocked dates + weekends ----------------------------------------
export function isDateBlocked(s: Settings, date: Date): boolean {
  return s.blockedDates.includes(ymd(date));
}
export function toggleBlockedDate(date: Date) {
  const s = getSettings();
  const key = ymd(date);
  const blocked = s.blockedDates.includes(key)
    ? s.blockedDates.filter((d) => d !== key)
    : [...s.blockedDates, key];
  saveSettings({ blockedDates: blocked });
}

// =====================================================================
// Marketing — email campaigns, social accounts, videos & short intros.
// Managed by Kits (marketing) & Josh (SEO/web). In production, campaigns
// send via an email service (Resend/Mailchimp); here they're simulated.
// =====================================================================
export type CampaignStatus = "draft" | "scheduled" | "sent";

export interface Campaign {
  id: string;
  subject: string;
  body: string;
  audience: "all" | CategorySlug;
  status: CampaignStatus;
  scheduledAt?: string;
  sentAt?: string;
  recipientCount?: number;
  author: string;
  createdAt: string;
}

export interface SocialAccount {
  platform: string; // key
  label: string;
  handle: string;
  url: string;
  connected: boolean;
}

export interface VideoItem {
  id: string;
  title: string;
  url: string;
  description: string;
  kind: "intro" | "promo" | "testimonial" | "other";
  createdAt: string;
}

export interface IntroItem {
  id: string;
  title: string;
  text: string;
}

// Number of contacts who opted into updates (the mailing list).
export function subscriberCount(): number {
  return getLeads().filter((l) => l.agreedToUpdates).length;
}
export function subscribers(): Lead[] {
  return getLeads().filter((l) => l.agreedToUpdates);
}

// --- Campaigns -------------------------------------------------------
export function getCampaigns(): Campaign[] {
  ensureSeed();
  seedIfMissing(KEYS.campaigns, seedCampaigns);
  return read<Campaign[]>(KEYS.campaigns, []).sort(
    (a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)
  );
}
export function addCampaign(
  input: Omit<Campaign, "id" | "createdAt" | "status"> & { status?: CampaignStatus }
): Campaign {
  const c: Campaign = {
    ...input,
    id: uid("cmp"),
    status: input.status ?? "draft",
    createdAt: new Date().toISOString(),
  };
  write(KEYS.campaigns, [c, ...read<Campaign[]>(KEYS.campaigns, [])]);
  return c;
}
export function updateCampaign(id: string, patch: Partial<Campaign>) {
  write(
    KEYS.campaigns,
    read<Campaign[]>(KEYS.campaigns, []).map((c) => (c.id === id ? { ...c, ...patch } : c))
  );
}
export function removeCampaign(id: string) {
  write(KEYS.campaigns, read<Campaign[]>(KEYS.campaigns, []).filter((c) => c.id !== id));
}

// Recipients on the list matching a campaign's audience.
export function campaignRecipientCount(audience: "all" | CategorySlug): number {
  const subs = subscribers();
  return audience === "all" ? subs.length : subs.filter((l) => l.categorySlug === audience).length;
}

// "Automation": send any scheduled campaign whose time has arrived. In
// production a cron/queue does this server-side; here it runs whenever the
// app is open (marketing page polls it). Returns how many were sent.
export function runDueCampaigns(): number {
  if (typeof window === "undefined") return 0;
  const now = Date.now();
  const all = read<Campaign[]>(KEYS.campaigns, []);
  let count = 0;
  const next = all.map((c) => {
    if (c.status === "scheduled" && c.scheduledAt && new Date(c.scheduledAt).getTime() <= now) {
      count++;
      return {
        ...c,
        status: "sent" as CampaignStatus,
        sentAt: new Date().toISOString(),
        recipientCount: campaignRecipientCount(c.audience),
      };
    }
    return c;
  });
  if (count > 0) write(KEYS.campaigns, next);
  return count;
}

// --- Automations (standing rules) ------------------------------------
export interface Automations {
  autoWelcome: boolean; // welcome email to every new subscriber
  monthlyDigest: boolean; // monthly newsletter reminder
}
const DEFAULT_AUTOMATIONS: Automations = { autoWelcome: true, monthlyDigest: false };
export function getAutomations(): Automations {
  return { ...DEFAULT_AUTOMATIONS, ...read<Partial<Automations>>(KEYS.automations, {}) };
}
export function saveAutomations(patch: Partial<Automations>) {
  write(KEYS.automations, { ...getAutomations(), ...patch });
}

// --- Social accounts -------------------------------------------------
const DEFAULT_SOCIAL: SocialAccount[] = [
  { platform: "facebook", label: "Facebook", handle: "@FaelightBusinessConsultancy", url: "https://facebook.com/FaelightBusinessConsultancy", connected: true },
  { platform: "instagram", label: "Instagram", handle: "@faelight", url: "https://instagram.com/faelight", connected: true },
  { platform: "linkedin", label: "LinkedIn", handle: "Faelight Business Consultancy", url: "", connected: false },
  { platform: "tiktok", label: "TikTok", handle: "@faelight", url: "", connected: false },
  { platform: "youtube", label: "YouTube", handle: "Faelight", url: "", connected: false },
];
export function getSocialAccounts(): SocialAccount[] {
  const stored = read<SocialAccount[]>(KEYS.social, []);
  // merge defaults with stored overrides by platform
  return DEFAULT_SOCIAL.map((d) => ({ ...d, ...stored.find((s) => s.platform === d.platform) }));
}
export function saveSocialAccount(platform: string, patch: Partial<SocialAccount>) {
  const all = getSocialAccounts().map((s) =>
    s.platform === platform ? { ...s, ...patch } : s
  );
  write(KEYS.social, all);
}

// --- Videos ----------------------------------------------------------
export function getVideos(): VideoItem[] {
  ensureSeed();
  seedIfMissing(KEYS.videos, seedVideos);
  return read<VideoItem[]>(KEYS.videos, []);
}
export function addVideo(input: Omit<VideoItem, "id" | "createdAt">): VideoItem {
  const v: VideoItem = { ...input, id: uid("vid"), createdAt: new Date().toISOString() };
  write(KEYS.videos, [v, ...read<VideoItem[]>(KEYS.videos, [])]);
  return v;
}
export function removeVideo(id: string) {
  write(KEYS.videos, read<VideoItem[]>(KEYS.videos, []).filter((v) => v.id !== id));
}

// --- Short intros ----------------------------------------------------
export function getIntros(): IntroItem[] {
  ensureSeed();
  seedIfMissing(KEYS.intros, seedIntros);
  return read<IntroItem[]>(KEYS.intros, []);
}
export function addIntro(input: Omit<IntroItem, "id">): IntroItem {
  const i: IntroItem = { ...input, id: uid("intro") };
  write(KEYS.intros, [i, ...read<IntroItem[]>(KEYS.intros, [])]);
  return i;
}
export function updateIntro(id: string, patch: Partial<IntroItem>) {
  write(KEYS.intros, read<IntroItem[]>(KEYS.intros, []).map((i) => (i.id === id ? { ...i, ...patch } : i)));
}
export function removeIntro(id: string) {
  write(KEYS.intros, read<IntroItem[]>(KEYS.intros, []).filter((i) => i.id !== id));
}

// --- Reviews / testimonials (admin-moderated) ------------------------
export type ReviewStatus = "pending" | "approved" | "rejected";
export interface Review {
  id: string;
  author: string;
  roleCompany: string;
  quote: string;
  categorySlug?: CategorySlug | null;
  rating?: number; // 1–5
  status: ReviewStatus;
  createdAt: string;
}

export function getReviews(): Review[] {
  ensureSeed();
  seedIfMissing(KEYS.reviews, seedReviews);
  return read<Review[]>(KEYS.reviews, []).sort(
    (a, b) => +new Date(b.createdAt) - +new Date(a.createdAt)
  );
}
export function getApprovedReviews(): Review[] {
  return getReviews().filter((r) => r.status === "approved");
}
export function addReview(
  input: Omit<Review, "id" | "createdAt" | "status"> & { status?: ReviewStatus }
): Review {
  const r: Review = {
    ...input,
    id: uid("rev"),
    status: input.status ?? "pending",
    createdAt: new Date().toISOString(),
  };
  write(KEYS.reviews, [r, ...read<Review[]>(KEYS.reviews, [])]);
  return r;
}
export function updateReview(id: string, patch: Partial<Review>) {
  write(KEYS.reviews, read<Review[]>(KEYS.reviews, []).map((r) => (r.id === id ? { ...r, ...patch } : r)));
}
export function removeReview(id: string) {
  write(KEYS.reviews, read<Review[]>(KEYS.reviews, []).filter((r) => r.id !== id));
}

// --- Brands / clients we support (admin-managed) ---------------------
export interface Brand {
  id: string;
  name: string;
  group: string; // one of BRAND_GROUPS
  logoUrl?: string; // URL or data: URI (uploaded)
  active: boolean;
  createdAt: string;
}

export function getBrands(): Brand[] {
  ensureSeed();
  seedIfMissing(KEYS.brands, seedBrands);
  return read<Brand[]>(KEYS.brands, []);
}
export function getActiveBrands(): Brand[] {
  return getBrands().filter((b) => b.active);
}
export function addBrand(input: Omit<Brand, "id" | "createdAt" | "active"> & { active?: boolean }): Brand {
  const b: Brand = { ...input, id: uid("brand"), active: input.active ?? true, createdAt: new Date().toISOString() };
  write(KEYS.brands, [...read<Brand[]>(KEYS.brands, []), b]);
  return b;
}
export function updateBrand(id: string, patch: Partial<Brand>) {
  write(KEYS.brands, read<Brand[]>(KEYS.brands, []).map((b) => (b.id === id ? { ...b, ...patch } : b)));
}
export function removeBrand(id: string) {
  write(KEYS.brands, read<Brand[]>(KEYS.brands, []).filter((b) => b.id !== id));
}

export function resetDemo() {
  if (typeof window === "undefined") return;
  [
    KEYS.leads, KEYS.notes, KEYS.bookings, KEYS.settings, KEYS.services,
    KEYS.events, KEYS.campaigns, KEYS.social, KEYS.videos, KEYS.intros,
    KEYS.automations, KEYS.reviews, KEYS.brands, KEYS.seeded,
  ].forEach((k) => localStorage.removeItem(k));
  ensureSeed(true);
  window.dispatchEvent(new CustomEvent("fae:store"));
}

// --- Seed ------------------------------------------------------------
function daysAgo(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() - n);
  d.setHours(9 + (n % 6), (n * 7) % 60, 0, 0);
  return d.toISOString();
}

function futureSlot(dayOffset: number, hour: number): { s: string; e: string } {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  d.setHours(hour, 0, 0, 0);
  const e = new Date(d);
  e.setHours(hour + 1);
  return { s: d.toISOString(), e: e.toISOString() };
}

function ensureSeed(force = false) {
  if (typeof window === "undefined") return;
  if (!force && localStorage.getItem(KEYS.seeded)) return;

  const seedLeads: Lead[] = [
    {
      id: "lead-seed-1",
      name: "Andrea Villaruz",
      email: "andrea.v@example.com",
      phone: "+63 917 111 2233",
      company: "Bloom & Co (café)",
      categorySlug: "systems",
      serviceId: "svc-discovery",
      message:
        "Our operations are held together by three group chats and my memory. Help.",
      source: "Facebook",
      utmSource: "facebook",
      utmMedium: "social",
      utmCampaign: "systems-launch",
      agreedToUpdates: true,
      status: "discovery booked",
      createdAt: daysAgo(2),
    },
    {
      id: "lead-seed-2",
      name: "Mark Delos Reyes",
      email: "mark.dr@example.com",
      phone: "+63 918 445 8890",
      company: "",
      categorySlug: "mentoring",
      serviceId: "svc-smart",
      message: "Career shifter here — want to become a VA. Where do I start?",
      source: "Referral from a friend",
      utmSource: "referral",
      utmMedium: "word-of-mouth",
      utmCampaign: "",
      agreedToUpdates: true,
      status: "contacted",
      createdAt: daysAgo(4),
    },
    {
      id: "lead-seed-3",
      name: "Grace Tanaka",
      email: "grace.t@example.com",
      phone: "",
      company: "Kaizen Remote Ltd",
      categorySlug: "experiences",
      serviceId: "svc-virtual-team",
      message:
        "Distributed team of 22 across 3 timezones. We need connection before year-end.",
      source: "LinkedIn",
      utmSource: "linkedin",
      utmMedium: "social",
      utmCampaign: "",
      agreedToUpdates: false,
      status: "proposal sent",
      createdAt: daysAgo(6),
    },
    {
      id: "lead-seed-4",
      name: "Bianca Ocampo",
      email: "bianca.o@example.com",
      phone: "+63 906 220 7781",
      company: "Ocampo Dental",
      categorySlug: "systems",
      serviceId: "svc-sop",
      message: "Onboarding new staff is chaos. Need SOPs and handover docs.",
      source: "Google search",
      utmSource: "google",
      utmMedium: "organic",
      utmCampaign: "",
      agreedToUpdates: true,
      status: "won",
      createdAt: daysAgo(11),
    },
    {
      id: "lead-seed-5",
      name: "Paolo Mendoza",
      email: "paolo.m@example.com",
      phone: "",
      company: "",
      categorySlug: "mentoring",
      serviceId: "svc-leadership",
      message: "Senior VA wanting to move into an EVA / team lead role.",
      source: "Instagram",
      utmSource: "instagram",
      utmMedium: "social",
      utmCampaign: "leadership",
      agreedToUpdates: true,
      status: "new",
      createdAt: daysAgo(1),
    },
    {
      id: "lead-seed-6",
      name: "Reina Salazar",
      email: "reina.s@example.com",
      phone: "+63 915 778 1122",
      company: "Salazar Realty",
      categorySlug: "systems",
      serviceId: "svc-notion-build",
      message: "Everything lives in my head. I want a Notion workspace for the team.",
      source: "A Faelight class or event",
      utmSource: "",
      utmMedium: "",
      utmCampaign: "",
      agreedToUpdates: true,
      status: "new",
      createdAt: daysAgo(0),
    },
    {
      id: "lead-seed-7",
      name: "Tim Ferrer",
      email: "tim.f@example.com",
      phone: "",
      company: "Ferrer Logistics",
      categorySlug: "systems",
      serviceId: "svc-audit",
      message: "Not sure this is the right time for us, budget is tight.",
      source: "Google search",
      utmSource: "google",
      utmMedium: "organic",
      utmCampaign: "",
      agreedToUpdates: false,
      status: "lost",
      createdAt: daysAgo(18),
    },
  ];

  const seedNotes: LeadNote[] = [
    {
      id: "note-seed-1",
      leadId: "lead-seed-1",
      author: "Kenny",
      note: "Booked her discovery call for this week. Very warm lead.",
      createdAt: daysAgo(2),
    },
    {
      id: "note-seed-2",
      leadId: "lead-seed-3",
      author: "Maia",
      note: "Sent proposal for a half-day experience + follow-up virtual session.",
      createdAt: daysAgo(3),
    },
    {
      id: "note-seed-3",
      leadId: "lead-seed-4",
      author: "Sassa",
      note: "Signed! SOP package kicks off next week. 🎉",
      createdAt: daysAgo(9),
    },
  ];

  const s1 = futureSlot(1, 14);
  const s2 = futureSlot(3, 11);
  const s3 = futureSlot(5, 16);
  const p1 = { s: daysAgo(9), e: daysAgo(9) };
  const seedBookings: Booking[] = [
    {
      id: "bk-seed-1",
      leadId: "lead-seed-1",
      bookingTypeId: "bt-discovery",
      bookingTypeName: "Discovery Consultation",
      startsAt: s1.s,
      endsAt: s1.e,
      clientName: "Andrea Villaruz",
      clientEmail: "andrea.v@example.com",
      clientPhone: "+63 917 111 2233",
      agenda: "Untangle café operations, discuss a starter system.",
      meetLink: "https://meet.google.com/fae-disc-and",
      status: "confirmed",
      createdAt: daysAgo(2),
    },
    {
      id: "bk-seed-2",
      leadId: null,
      bookingTypeId: "bt-notion",
      bookingTypeName: "Notion Consultation",
      startsAt: s2.s,
      endsAt: s2.e,
      clientName: "Jules Prieto",
      clientEmail: "jules.p@example.com",
      clientPhone: "",
      agenda: "Plan a Notion CRM for a small agency.",
      meetLink: "https://meet.google.com/fae-notion-jul",
      status: "confirmed",
      createdAt: daysAgo(1),
    },
    {
      id: "bk-seed-3",
      leadId: null,
      bookingTypeId: "bt-coaching",
      bookingTypeName: "Coaching / 1:1 Session",
      startsAt: s3.s,
      endsAt: s3.e,
      clientName: "Nadia Cruz",
      clientEmail: "nadia.c@example.com",
      clientPhone: "+63 927 900 4415",
      agenda: "Leadership coaching — stepping into an EVA role.",
      meetLink: "https://meet.google.com/fae-coach-nad",
      status: "confirmed",
      createdAt: daysAgo(0),
    },
    {
      id: "bk-seed-4",
      leadId: "lead-seed-4",
      bookingTypeId: "bt-discovery",
      bookingTypeName: "Discovery Consultation",
      startsAt: p1.s,
      endsAt: p1.e,
      clientName: "Bianca Ocampo",
      clientEmail: "bianca.o@example.com",
      clientPhone: "+63 906 220 7781",
      agenda: "SOP scoping for dental clinic onboarding.",
      meetLink: "https://meet.google.com/fae-disc-bia",
      status: "completed",
      feeLabel: "₱2,500 — payable after confirmation",
      paymentStatus: "paid",
      amountPaid: 2500,
      paymentMethod: "GCash",
      paidAt: daysAgo(9),
      createdAt: daysAgo(12),
    },
  ];

  // A couple of calendar events — one personal hold (app), one synced in
  // from the linked calendar (google) — to show two-way sync.
  const evDay = (offset: number) => {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    return ymd(d);
  };
  const seedEvents: CalendarEvent[] = [
    {
      id: "ev-seed-1",
      date: evDay(2),
      startMin: 10 * 60,
      endMin: 11 * 60,
      title: "Deep work — no meetings",
      source: "app",
      allDay: false,
    },
    {
      id: "ev-seed-2",
      date: evDay(4),
      startMin: 15 * 60,
      endMin: 16 * 60 + 30,
      title: "Client call (from Google)",
      source: "google",
      allDay: false,
    },
  ];

  write(KEYS.leads, seedLeads);
  write(KEYS.notes, seedNotes);
  write(KEYS.bookings, seedBookings);
  write(KEYS.events, seedEvents);
  localStorage.setItem(KEYS.seeded, "1");
}

// Marketing collections seed on first access (so they also populate for
// sessions seeded before marketing existed). Reset clears them → reseed.
function seedCampaigns(): Campaign[] {
  return [
    {
      id: "cmp-seed-1",
      subject: "✦ Welcome to the Faelight circle",
      body: "Hi there — thanks for joining us. Here's what to expect: occasional tips on systems and VA skills, first dibs on classes, and the odd bit of Faelight magic. People first. Systems second. Magic throughout.",
      audience: "all", status: "sent", sentAt: daysAgo(10), recipientCount: 4,
      author: "Kits", createdAt: daysAgo(11),
    },
    {
      id: "cmp-seed-2",
      subject: "New Foundations cohort opening soon",
      body: "Our next small-cohort Foundations Class is opening for enrolment. Reply to reserve a seat — spaces are limited because people are not sardines.",
      audience: "mentoring", status: "draft", author: "Kits", createdAt: daysAgo(1),
    },
    {
      id: "cmp-seed-3",
      subject: "This month at Faelight ✦",
      body: "A little roundup of what's new — classes, tips and a peek behind the scenes.",
      audience: "all", status: "scheduled", scheduledAt: futureISO(3, 9),
      author: "Kits", createdAt: daysAgo(0),
    },
  ];
}
function futureISO(dayOffset: number, hour: number): string {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);
  d.setHours(hour, 0, 0, 0);
  return d.toISOString();
}
function seedVideos(): VideoItem[] {
  return [
    { id: "vid-seed-1", title: "Meet Faelight — 60-second intro", url: "https://youtu.be/faelight-intro", description: "A short brand intro: who we are and how we help people and businesses.", kind: "intro", createdAt: daysAgo(20) },
    { id: "vid-seed-2", title: "What is the Mentoring Circle?", url: "https://youtu.be/faelight-mentoring", description: "Kits walks through the VA training pathway in 90 seconds.", kind: "promo", createdAt: daysAgo(6) },
  ];
}
function seedIntros(): IntroItem[] {
  return [
    { id: "intro-seed-1", title: "One-liner", text: "Helping people become more capable. Helping businesses become easier to run." },
    { id: "intro-seed-2", title: "Short bio (social)", text: "Faelight is a Philippine business consultancy: VA mentoring, operations systems and virtual experiences — with a little magic. People first. Systems second. Magic throughout." },
    { id: "intro-seed-3", title: "Elevator pitch", text: "For businesses whose operations are held together by vibes, memory and seventeen tabs — we build systems that create freedom, and the people who can run them." },
  ];
}
function seedReviews(): Review[] {
  return [
    { id: "rev-seed-1", author: "Andrea V.", roleCompany: "Operations Lead, remote team", quote: "Faelight untangled a year of scattered tools into one calm system my team can actually run without me.", categorySlug: "systems", rating: 5, status: "approved", createdAt: daysAgo(14) },
    { id: "rev-seed-2", author: "Mark D.", roleCompany: "Foundations Class graduate", quote: "I came in unsure I could be a VA and left with a portfolio, real tools and the confidence to land my first client.", categorySlug: "mentoring", rating: 5, status: "approved", createdAt: daysAgo(20) },
    { id: "rev-seed-3", author: "Grace T.", roleCompany: "Women's community organiser", quote: "Our virtual experience felt warm, story-led and genuinely fun — people are still talking about it.", categorySlug: "experiences", rating: 5, status: "approved", createdAt: daysAgo(9) },
    { id: "rev-seed-4", author: "Bianca O.", roleCompany: "Ocampo Dental", quote: "The SOPs Faelight built made onboarding new staff painless. Wish we'd done it a year ago!", categorySlug: "systems", rating: 5, status: "pending", createdAt: daysAgo(2) },
    { id: "rev-seed-5", author: "Paolo M.", roleCompany: "Senior VA", quote: "The leadership class pushed me to own my work. Landed an EVA role two months later.", categorySlug: "mentoring", rating: 4, status: "pending", createdAt: daysAgo(1) },
  ];
}

function seedBrands(): Brand[] {
  const groups: Record<string, string[]> = {
    "Training & Mentorship": ["Remoworks International", "UnCapped Potential", "Zolomon AI", "YourPockerPH", "Cebuana", "DC Creative", "dela Cruz & Cruz Law Offices", "Elyxion", "NZM", "Patricia Yap Consultancy", "Raebert Santos", "Hannah KC"],
    "Executive & Admin Support": ["Snapsil Systems", "TXM", "BNI"],
    "Operations & Business Systems": ["Flawless Aesthetics Clinic", "Steps2Life Health", "Ultra Manpower", "Renee Consulting", "SpeechCoach"],
    "Marketing": ["Clara's Kitchen", "Mean Bean Coffee Co.", "The Oil Temple", "Studio D Papeterie", "5MD Design Pty Ltd"],
  };
  const out: Brand[] = [];
  Object.entries(groups).forEach(([group, names]) => {
    names.forEach((name, i) => {
      out.push({ id: `brand-${group.slice(0, 3).toLowerCase()}-${i}`, name, group, active: true, createdAt: new Date().toISOString() });
    });
  });
  return out;
}

function seedIfMissing<T>(key: string, factory: () => T[]) {
  if (typeof window === "undefined") return;
  if (localStorage.getItem(key) === null) write(key, factory());
}
